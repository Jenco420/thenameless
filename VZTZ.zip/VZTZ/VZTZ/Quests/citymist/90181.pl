sub EVENT_DEATH {
	quest::faction(342,10);
	quest::exp(10000);
}