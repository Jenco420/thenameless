sub EVENT_SAY {
	if ($text=~/Hail/i) {
		quest::say("Save my.. Soul.. Find.. Wizard.. Desp..");
	}
}

sub EVENT_ITEM {
	# Hand in Mardon's Bottle
	if ($itemcount{12963} == 1) {
		quest::summonitem(12966); # Bottle of swirling smoke (Mardon's soul)
		quest::depop();
	} else {
		plugin::return_items(\%itemcount);
	}
}

