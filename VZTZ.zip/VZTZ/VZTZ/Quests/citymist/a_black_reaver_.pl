# name: a_black_reaver_  ID: 90007  should spawn : LORD RAK ASHIIR 90174

sub EVENT_DEATH {
	my $a = quest::ChooseRandom(90007,90007,90007,90007,90007,90007,90007,90007,90007,90174,90174,90174);
	my $x = $npc->GetX();
	my $y = $npc->GetY();
	my $z = $npc->GetZ();
	my $h = $npc->GetHeading();
	quest::spawn2($a,0,0,$x,$y,$z,$h);
}