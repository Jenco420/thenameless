#NPC #a_black_reaver ID: 90005 should spawn: NEH ASHIIR

sub EVENT_DEATH {
	my $a = quest::ChooseRandom(90005,90005,90005,90005,90005,90005,90005,90005,90005,90184,90184,90184);
	my $x = $npc->GetX();
	my $y = $npc->GetY();
	my $z = $npc->GetZ();
	my $h = $npc->GetHeading();
	quest::spawn2($a,0,0,$x,$y,$z,$h);
}