# a_black_reaver   id: 90004  should spawn: LORD GHIOSK

sub EVENT_DEATH {
	my $a = quest::ChooseRandom(90004,90004,90004,90004,90004,90004,90004,90004,90004,90180,90180,90180);
	my $x = $npc->GetX();
	my $y = $npc->GetY();
	my $z = $npc->GetZ();
	my $h = $npc->GetHeading();
	quest::spawn2($a,0,0,$x,$y,$z,$h);
}