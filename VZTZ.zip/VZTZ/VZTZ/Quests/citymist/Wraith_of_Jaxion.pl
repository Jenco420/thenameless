sub EVENT_ITEM {
	#Dull Ruby
	if ($itemcount{10633} == 1) {
		quest::summonitem(10620); #Enchanted Ruby
	} else {
		plugin::return_items(\%itemcount);
	}
}