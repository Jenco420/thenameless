sub EVENT_DEATH {
	quest::say("You have run me through! Beware the Pirates of Gunthak.. They will avenge me.. Unngh!!");
	quest::spawn2(9948326,0,0,-5386.8,783.0,12.9,165.8);
}