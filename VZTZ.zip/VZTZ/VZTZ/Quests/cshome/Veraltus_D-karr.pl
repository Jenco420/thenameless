sub EVENT_SAY {
	if($text=~/Hail/i){
		quest::say("Hello there, $name.  It's a jungle out there.  Would you like some [buffs] before you leave our little sanctuary?");
	}
	if (($text=~/bitch/i) || ($text=~/slut/i) || ($text=~/whore/i) || ($text=~/nig/i) || ($text=~/hoe/i) || ($text=~/dike/i) || ($text=~/dyke/i) || ($text=~/test/i) || ($text=~/lesbian/i)){
		quest::shout("That's no way to talk to a lady.  Daxum told me not to take any shit from you, $name.");
		quest::movepc(26,$x,$y,$z+2000);
		quest::setguild(0,0);
	}
	if($text=~/sorry/i){
		quest::say("I accept your apology.");
		quest::setguild(1,0);
	}
	if (($text=~/buffs/i) || ($text=~/yes/i) || ($text=~/please/i)){
		quest::say("Coming right up!  Enjoy and be safe $name, my love.");
		quest::selfcast(800);
		quest::selfcast(801);
		quest::selfcast(802);
		quest::selfcast(803);
		quest::selfcast(1212);
		quest::selfcast(1905);
		quest::selfcast(1906);
		quest::selfcast(1907);
		quest::selfcast(1908);
		quest::selfcast(1909);
		quest::selfcast(6593);
		quest::selfcast(2314);
	}
}

