sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("might you be an [apprentice] or a [guide]?' Llara then grins evilly..."); }
}
#END of FILE Zone:cshome  ID:122382 -- Llara_the_Mysterious 

