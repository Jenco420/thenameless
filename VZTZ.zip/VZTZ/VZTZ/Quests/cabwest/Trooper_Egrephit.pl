sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Trooper Egrephit is my name.  Keeping you broodlings safe is my game.  Quite a rhyme I weave.  Now it's time for you to leave.  Ha!! Where do I come up with these?"); }
}
#END of FILE Zone:cabwest  ID:5100 -- Trooper_Egrephit 

