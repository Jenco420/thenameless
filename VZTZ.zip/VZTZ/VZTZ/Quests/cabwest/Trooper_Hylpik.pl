sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You look a bit encumbered.  You should visit The Block."); }
}
#END of FILE Zone:cabwest  ID:5114 -- Trooper_Hylpik 

