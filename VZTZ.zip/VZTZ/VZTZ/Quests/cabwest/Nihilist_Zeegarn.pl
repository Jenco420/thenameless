sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Mind yourself within Cabilis.  We will not tolerate any mischief.  If you don't heed my warnings. you may be sentenced to the pit of the Crusaders of Greenmist.  You don't want that!  Also. you should always wear your robe when entering these walls.  You do have your Drape of the Brood. correct?"); }
}
#END of FILE Zone:cabwest  ID:3698 -- Nihilist_Zeegarn 

