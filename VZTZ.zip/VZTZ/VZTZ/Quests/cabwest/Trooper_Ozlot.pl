sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. citizen!  If it is a good time you are seeking. you should head toward the tavern.  You can't miss it.  There is only one.  The emperor says we should spend most of our time training. not in revelry.  We troopers try."); }
}
#END of FILE Zone:cabwest  ID:5135 -- Trooper_Ozlot 

