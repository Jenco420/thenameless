sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("The waters of Cabilis are teeming with life.  A good fisherman could make heavy coin catching fish."); }
}
#END of FILE Zone:cabwest  ID:5099 -- Trooper_Eglo 

