sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. citizen.  Looking for healing or other such services?  If so. then I urge you to seek out the Temple of Terror.  The hierophants will see to it for you."); }
}
#END of FILE Zone:cabwest  ID:5133 -- Trooper_Ogmire 

