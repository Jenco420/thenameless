sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("A forged weapon is no match for the memories and power trapped within a weapon made of bone."); }
}
#END of FILE Zone:cabwest  ID:3579 -- Mohin 

