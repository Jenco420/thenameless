sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. $name. perhaps you've come to purchase some of my rare supplies? I have a special blend of eleven herbs and spices......oh wait.....I'm sold out of that......anyway. what can I do for you?"); }
}
#END of FILE Zone:cabwest  ID:2815 -- Jaxxtz 

