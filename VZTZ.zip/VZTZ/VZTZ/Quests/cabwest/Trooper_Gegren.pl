sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Do not approach the Tower of Death unless you have been summoned to rebirth.  My brother was unfortunate enough to venture into their halls and he has never been seen again."); }
}
#END of FILE Zone:cabwest  ID:5105 -- Trooper_Gegren 

