sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Much beauty can be found upon the skins of our enemies.  And... even upon that of our own allies?"); }
}
#END of FILE Zone:cabwest  ID:2891 -- Kamzar 

