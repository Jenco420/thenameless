sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I am glad the crusaders assist with the patrols of Cabilis.  Their powers of healing are always welcomed by the troopers."); }
}
#END of FILE Zone:cabwest  ID:5141 -- Trooper_Shyzin 

