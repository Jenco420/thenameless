sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("If you are searching for rare items. I would suggest the merchants of the Brood of Kotiz.  They often carry rare trinkets from beyond the walls of Cabilis."); }
}
#END of FILE Zone:cabwest  ID:5138 -- Trooper_Ryzee 

