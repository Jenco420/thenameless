sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Ahh. welcome! More souls to succumb to the inhabitants of the Outlands! My army of undead will grow stronger by the day. but it would be a pity if you perished before doing a [mortal bidding] for me.");
}
if($text=~/what mortal bidding/i){
quest::say("I see it as a win-win situation for me. If you succeed. I'll gain more power from the knowledge you bring back to me. If you fail. you become another addition to my undead minions. Thus. you cannot fail me in returning a scroll of Splurt. Defoliation. Covergence. or Thrall of Bones. In return. I will part with a scroll of mine."); }
}

sub EVENT_ITEM(){
  if (plugin::check_handin(\%itemcount, 19296 => 1) || # Defoilation
      plugin::check_handin(\%itemcount, 19423 => 1) || # convergence
      plugin::check_handin(\%itemcount, 19294 => 1) || # splurt
      plugin::check_handin(\%itemcount, 19299 => 1)) { # Thrall of bones
    quest::say("Here is the scroll that I promised. We have both gained much knowledge today. I hope to do business with you again soon. Farewell!");      
    quest::summonitem(quest::ChooseRandom(19297,19421,19408,19409));
    #Minion of Shadows, Sacrifice, Scent of Terris, Shadowbond
    quest::exp(500);
  }
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}
#END of FILE Zone:overthere  ID:93102 -- Vaean_the_Night 

