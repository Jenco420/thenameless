sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Have you heard the latest babble?  Giant stingers which spew forth flames and fight with the tactics of a lizard are said to inhabit the Overthere."); }
}
#END of FILE Zone:cabwest  ID:5147 -- Trooper_Yegmesh 

