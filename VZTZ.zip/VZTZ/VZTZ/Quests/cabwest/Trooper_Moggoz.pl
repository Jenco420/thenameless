sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I have heard stories that there is a lost valley of great treasures within the Dreadlands.  Some say it was there the Green Death first arose."); }
}
#END of FILE Zone:cabwest  ID:5126 -- Trooper_Moggoz 

