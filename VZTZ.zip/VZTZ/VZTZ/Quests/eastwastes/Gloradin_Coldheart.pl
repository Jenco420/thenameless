sub EVENT_ITEM { 
if($itemcount{30163} == 1){
quest::say("Thank you. I will return to the Dain and inform him that the battle is underway. Please escort Garadain to the battlefield and see that he returns safely. May Brell bless you and bring you victory over these beasts."); }
}
#END of FILE Zone:eastwastes  ID:116138 -- Gloradin_Coldheart 

