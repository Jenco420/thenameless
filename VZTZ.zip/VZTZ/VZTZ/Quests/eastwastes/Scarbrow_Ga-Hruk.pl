# Part of Coldain Ring 5 Quest

sub EVENT_SPAWN {
  quest::shout("For the glory of the Ry`Gorr, charge!!");
}

sub EVENT_AGGRO {
  quest::say("Crush, maim, kill, and defy! For dinner tonight, your brains we shall fry!");
}

# Quest by mystic414