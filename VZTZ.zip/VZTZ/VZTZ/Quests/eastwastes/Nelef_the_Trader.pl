sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Good day to you. friend! Tell me. have you [traversed the cold] and the muck to forge through the forsaken tomb of the sleeping dragon? Perhaps you've come across mighty beasts with [prismatic power] beyond imagination?!"); }
}
#END of FILE Zone:eastwastes  ID:116086 -- Nelef_the_Trader 

