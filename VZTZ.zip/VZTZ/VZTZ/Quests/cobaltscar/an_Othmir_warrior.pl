sub EVENT_SAY { 
  if($text=~/Hail/i){
    quest::say("Welcome strange one! I am on watch duty so I'm afraid I have not the time to converse. Perhaps when my shift is over we can exchange words over a bowl of spicy clam chowder.");
  }
}

#END of FILE Zone:cobaltscar  ID:117013 -- an_Othmir_warrior 

