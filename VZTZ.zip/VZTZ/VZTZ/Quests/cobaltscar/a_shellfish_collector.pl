sub EVENT_SAY { 
  if($text=~/Hail/i){
    quest::say("Excuse me, strange one, for my rudeness, but I must finish collecting the shellfish for tonight's feast in time for them to be properly prepared.");
  }
}

#END of FILE Zone:cobaltscar  ID:117037 -- a_shellfish_collector 

