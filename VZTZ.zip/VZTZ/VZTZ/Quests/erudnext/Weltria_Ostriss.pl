sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Good day. $name. I assist in maintaining an accurate collection of historical tomes here in the great library of Erudin. One of our citizens recently escaped the dungeons of the Kobold warrens and tells of a Kobold lore keeper who keeps a collection of scrolls detailing the history of their kind. Are you capable of obtaining those scrolls for our library?"); }
}
#END of FILE Zone:erudnext  ID:98015 -- Weltria_Ostriss 

