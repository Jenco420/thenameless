sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("It is good to meet you. $name.  To enter the Temple of Divine Light is to invite Quellious into your body and soul.  Tranquility is our way and. as such. we do all we can to uphold it.  Are you a [cleric of Quellious]. or am I mistaken?");
}
if($text=~/i am a cleric of the quellious/i){
quest::say("I have a small task for you then. Go to the city library and ask the librarian for the book 'The Testament of Vanear'. I shall require it for further studies. Do not return empty-handed or you shall know my rage."); 
}
}
#END of FILE Zone:erudnext  ID:98046 -- Rarnan_Lapice 

