sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings. adventurer! After all those months of sweaty. hot and dirty battling of beasts untold. it is time to treat yourself to a tall. cool grog!"); }
if($text=~/What Erud's Tonic/i){
quest::say("Long ago, the great Erud found that excessive indulgence in spirits led to diminished mental awareness. His love of Kaladim brandy led him to concoct Erud's Tonic. The tonic blocked the effects of all spirits. Unfortunately, it is made from our precious Vasty Deep water and therefore is not permitted to be exported or given to non-Erudites or adventuring Erudites.")
}
if($text=~/Can I have some Erud's Tonic/i){
quest::say("The sale or provision of Erud's Tonic to travelers is prohibited!  Ha! The closest you will get to tonic is in the library. That's assuming you know how to spell tonic. Bwaha ha! When you see the bookworm give her a KISS for me! HAHA!!")
}
}
#END of FILE Zone:erudnext  ID:98066 -- Geoard_Bluehawk 

