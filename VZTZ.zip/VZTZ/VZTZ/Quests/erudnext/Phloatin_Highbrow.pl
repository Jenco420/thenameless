sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("Ahoy there. [sailor]!"); 
	}
}
#END of FILE Zone:erudnext  ID:98037 -- Phloatin_Highbrow 

