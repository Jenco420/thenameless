sub EVENT_SIGNAL {
	if ($signal == 399) {
		quest::emote("barks in response to Athele's words.");
	}
}