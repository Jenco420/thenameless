sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. traveler!  Might I escort you through to Highpass?  The path ahead is filled with giants and many other hungry beasts. I assure you. you will be safe with me.  I must admit. I am quite experienced in the ways of the warrior.  Do you [wish an escort] or will you [travel alone]?"); }
}
#END of FILE Zone:eastkarana  ID:15048 -- Sir_Morgan 

