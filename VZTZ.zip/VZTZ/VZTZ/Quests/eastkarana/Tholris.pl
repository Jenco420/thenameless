sub EVENT_SAY {
	if ($text=~/hail/i) {
		quest::emote("stares in contemplation at the landscape.");
		quest::signalwith(15044,399,200);
	}
}

sub EVENT_SIGNAL {
	if ($signal == 99) {
		quest::emote("breathes quickly and sweats as he channels his spirit into the sky.");
	}
}