sub EVENT_SPAWN {
	quest::shout("We come for you, fools. Your reign of weakness over the powers of the land comes to an end now!");
	quest::settimer("despawn",600);
}

sub EVENT_ATTACK {
	quest::stoptimer("despawn");
}

sub EVENT_TIMER {
	quest::stoptimer("despawn");
	quest::depop();
}

sub EVENT_DEATH {
	quest::stoptimer("despawn");
}