sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hello! Good to meet you. The road ahead is full of all sorts of nasty creatures. If I were you. I would speak with my master. Sir Morgan."); }
}
#END of FILE Zone:eastkarana  ID:15047 -- Squire_Wimbley 

