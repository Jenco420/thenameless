#a_spectral_crusader QUEST: The Visceral Dagger zone:Dalnir by:Jaxx

sub EVENT_SAY {
	if($text=~/Greenmist/i) {
		quest::say("'Mighty was the mist which covered the land. Mighty is the blade wielded by a crusader.");
	}
	if($text=~/Golin/i) {
		quest::emote("swipes his hand toward his own head in a chopping motion. 'Stuck between crypt and dust.");
	}
	if($text=~/visceral dagger/i) {
		quest::say("Shattered!! Three within the crypt. A master must go. To the [grand forge] they must go. Three become one with the spirit hammer.");
	}
	if($text=~/grand forge/i) {
		quest::emote("points to the ground. 'Beyond the doors lies a forge unlike any other.");
	}
}