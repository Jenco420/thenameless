#a_tormented_tradesman Greenmist quest chain. By: Jaxx

sub EVENT_ITEM {
	if($itemcount{3889} == 1) {
		quest::me("The undead entity looks in the mirror and appears to be stunned by the memory of his former self. He drops the mirror, which causes it to crack slightly. You immediately grab it and place it back in your bag. The spirit looks at you and begins to transform. Ethereal strands of muscle, blood, and flesh come together and the Haggle Baron Dalnir appears.");
		quest::summonitem(3896);
		quest::spawn2(104065, 0, 0, 21.7, -229.6, -177.6, 1.9);
	}	
}