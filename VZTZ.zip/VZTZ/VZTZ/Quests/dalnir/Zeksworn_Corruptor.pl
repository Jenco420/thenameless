                                                                     
                                                                     
                                                                     
                                             
#need to...

#o  get npc id's and replace the 99999
#  get npc hps for reset.




#Raid Mob 1

 #on aggro, and deaggro, cast: 8449
 #every 40 sec casts a buff on himself: 8450
 #every 4 sec casts random poison on $hateRand
 #every 24 sec cast Caystic Destruction 7113
 #when he dies, he spawns a hand in quest mob
 #reset on deaggro

my $pickTarget;
my $hateRand;
my $hateTop;
my $hateName;
my $hateID;
my $x;
my $y;
my $z;
my $h;

sub EVENT_AGGRO
{
quest::shout2("You will not have me Tunare!");
}

sub EVENT_COMBAT
{
    #1 - enter combat, 0 - leave combat
    if($combat_state == 1)
    {
        $npc->CastSpell(8449, '104076');
        quest::settimer("buff", 40);
        quest::settimer("poison", 4);
        quest::settimer("cd", 24);
    }
    elsif($combat_state == 0)
    {
        $npc->CastSpell(8449, '104076');
        quest::stoptimer("buff");
        quest::stoptimer("poison");
        quest::stoptimer("cd");
        #heals mob to full - make # equal to total health of NPC
        $npc->SetHP(64000);
    }
}


sub EVENT_TIMER
{
    
    if ($timer eq "buff")
    {
        $npc->CastSpell(8450, '104076');
    }
    if ($timer eq "poison")
    {
		$hateRand = $npc->GetHateRandom();
        $hateID = $hateRand->GetID();
        $npc->CastSpell(ChooseRandom(436,435,1590,4874,3492,5527,4466), $hateID);
    }
    
    if ($timer eq "cd")
    {
		$hateRand = $npc->GetHateRandom();
        $hateID = $hateRand->GetID();
        $npc->CastSpell(7113, $hateID);
    }
    
}

sub EVENT_SLAY
{
    $npc->CastSpell(8450, '104076');
}


sub EVENT_DEATH
{
  	quest::shout2("Noooo!");  
}

