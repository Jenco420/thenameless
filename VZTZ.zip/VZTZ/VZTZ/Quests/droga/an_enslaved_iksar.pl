#an_enslaved_iksar (a.k.a. Argest) Temple of Droga, Test of the Lord SK weapon - By Jaxx

sub EVENT_ITEM {
	if($itemcount{12713} == 1 && $itemcount{12712} == 1 && $itemcount{12708} == 1) {
		quest::say("Thank you for rescuing me. Here, take this needle, it will allow you to use the stupendous machine across from this cell.");
		quest::summonitem(12714);
		quest::exp(5000);
	}
}