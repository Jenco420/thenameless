sub EVENT_SPAWN{
        $x = $npc->GetX();
        $y = $npc->GetY();
        quest::set_proximity($x - 50, $x + 50, $y - 50, $y + 50);
}

sub EVENT_ENTER {
        $n = $client->GetName();
        $client->Message(0, "You hear crackling as dangerous creatures path near you, clattering at the smell of your blood!");
}