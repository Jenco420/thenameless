sub EVENT_ATTACK{
	quest::say("Yum, me make your head into $race soup!");
}

sub EVENT_DEATH{
	quest::say("Ugh! Me ded!");
}