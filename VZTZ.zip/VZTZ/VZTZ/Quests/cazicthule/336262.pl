sub EVENT_ATTATCK{
	quest::shout("YOU WILL NOT SPOIL THE SUMMONING OF CAZIC-THULE! FEEL THE FURY OF A THOUSAND AGES!!!!!");
}

sub EVENT_DEATH{
	quest::shout("Agghhh... I have failed you... my lord!!!");
}

sub EVENT_SLAY{
	quest::shout("Another sacrifice for Cazic-Thule!");
}