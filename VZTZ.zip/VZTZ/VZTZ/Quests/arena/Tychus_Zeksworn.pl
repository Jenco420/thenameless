#Tychus Zeksworn
 #2 ae's every 20 seconds - random - casts on random hate list (50/50 chance its random, or on main tank)
 #start at 95%
 #mob heals self each time it kills someone sub EVENT_SLAY - Triggered whenever an NPC kills someone.
 #Black Mark of Talon: 8451
 #Black Mark of Valon: 8472
 #on death spawns hand in quest mob
 
my $pickTarget;
my $hateRand;
my $hateTop;
my $hateName;
my $hateID;
my $pickSpell;
my $castSpell;
my $x;
my $y;
my $z;
my $h;

#sub EVENT_SPAWN
#{
#  quest::setnexthpevent(95);
#}


sub EVENT_AGGRO
{
	quest::shout2("None shall stand before the might of Rallos Zek!");
	quest::settimer("cast", 12);
}


sub EVENT_COMBAT
{
    if($combat_state == 0)
    {
        quest::stoptimer("cast");
        #heals mob to full - make # equal to total health of NPC
        $npc->SetHP(72000);
    }
}

#sub EVENT_HP
#{
 #   if($hpevent <= 95)
  #  {
   #   quest::shout("You will all regret this day!");
    #  quest::settimer("cast", 12);
    #}   
#}

sub EVENT_TIMER
{
    
    if ($timer eq "cast")
    {
        #choose a random #, either 0, or 1
        $pickTarget = quest::ChooseRandom(0,1);
        
        #choose a random #, either 2, or 3
        $pickSpell = quest::ChooseRandom(0,1);

        #cast spell on top of hate list
        
        if($pickSpell == 0)
        {
	    
            $castSpell = 8451;
        }
        
        else
        {
            $castSpell = 8472;
        }
        
        if($pickTarget == 0)
        {
            #$hateRand = $npc->GetHateRandom();
            $hateTop = $npc->GetHateTop();
            $hateName = $hateTop->GetName();
            $hateID = $hateTop->GetID(); 
            $npc->CastSpell($castSpell, $hateID);
        }
        
        #pick random target off of hate list
        elsif($pickTarget == 1)
        {
            #$hateRand = $npc->GetHateRandom();
            $hateRand = $npc->GetHateRandom();
            $hateName = $hateRand->GetName();
            $hateID = $hateRand->GetID(); 
            $npc->CastSpell($castSpell, $hateID);
        }   

	if($castSpell == 8472) {
		quest::shout("Feel the glorious might of Vallon Zek!");
	}else{
		quest::shout("Feel the glorious might of Tallon Zek!");
	}
    }
}

sub EVENT_SLAY
{
   $npc->SetHP($npc->GetHP() + 10000);   
}

sub EVENT_DEATH
{
	$x = $npc->GetX();
	$y = $npc->GetY();
	$z = $npc->GetZ();
	$h = $npc->GetHeading();
	quest::shout2("Death, is but an honor.");  
  	quest::spawn2 (127105,0,0,$x,$y+10,$z,$h);
}
 
 #Main NPC 1
 #Name Bond Man
 #every minute casts a buff on himself
 #every 20 seconds casts essence bond randomly on hatelist - GetHateRandom()
 #essence bond: 8477
 #when he dies, he spawns a hand in quest mob
 #reset on deaggro
 
 #spawned quest NPC Mob
 #despawns Main NPC 1 after 20 minutes
 #does hand in for quest items for Quest NPC 2
 
 
 
 #spawned quest NPC Mob 2
 #handles quest turn ins for NPC 1
 #despawns Main NPC 2 after 20 minutes
 #reset on deaggro