#Vision_of_Tunare ID:127105      Zone: Lake of Ill Omen   Prophet of Zek GM Event   quest file by: Jaxx

sub EVENT_SPAWN {
	quest::emote("appears before you. 'You have destroyed Tychus Zeksworn, the Harbinger of War! But unfortunately, it may be [too late].");
	quest::settimer("depop",300);
}

sub EVENT_SAY {
	if($text=~/too late/i) {
		quest::say("Unfortunately so. Tychus Zeksworn has already corrupted one of my own children. [Painroot], a once noble hero and Champion of my realm, is now tainted by Evil, and must be stopped!");
	}
	if($text=~/Painroot/i) {
		quest::emote("nods and says 'It is truely a shame. You must find him, and slay him. Once you have done so, return to me with [proof] of his demise.");
	}
	if($text=~/proof/i) {
		quest::say("Bring me a token made from Painroot's bark as proof of his demise, and be rewarded greatly.");
	}
}

sub EVENT_ITEM {
	if($itemcount{99921} == 1) { #Rogue
		quest::say("Yes! You have done it! Congratulations, $name, please accept this reward on my behalf.");
		quest::summonitem(99935);
	}
	elsif($itemcount{99915} == 1) { #Ranger
		quest::say("Yes! You have done it! Congratulations, $name, please accept this reward on my behalf.");
		quest::summonitem(99929);
	}
	elsif($itemcount{99916} == 1) { #Shadowknight
		quest::say("Yes! You have done it! Congratulations, $name, please accept this reward on my behalf.");
		quest::summonitem(99930);
	}
	elsif($itemcount{99914} == 1) { #Cleric
		quest::say("Yes! You have done it! Congratulations, $name, please accept this reward on my behalf.");
		quest::summonitem(99928);
	}
	elsif($itemcount{99923} == 1) { #Necromancer
		quest::say("Yes! You have done it! Congratulations, $name, please accept this reward on my behalf.");
		quest::summonitem(99937);
	}
	elsif($itemcount{99925} == 1) { #Enchanter
		quest::say("Yes! You have done it! Congratulations, $name, please accept this reward on my behalf.");
		quest::summonitem(99939);
	}
	elsif($itemcount{99918} == 1) { #Druid
		quest::say("Yes! You have done it! Congratulations, $name, please accept this reward on my behalf.");
		quest::summonitem(99932);
	}
	else {
    plugin::return_items(\%itemcount);
	}
}

sub EVENT_TIMER {
	quest::depop();
	quest::stoptimer("depop");
}

#End of File. Quest by: Jaxx