sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("Leave me be, worm! I have important matters to attend to!"); 
	}
}

sub EVENT_ATTACK {
	quest::say("Foolish mortal, you dare attack me?! Die!!");  
}
#END of FILE Zone:everfrost  ID:3233 -- Lich_of_Miragul 

