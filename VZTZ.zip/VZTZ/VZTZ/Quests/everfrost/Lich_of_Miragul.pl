sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("arrrrrrrg"); 
	}
}

sub EVENT_ITEM {
	#Phylactery
	if($itemcount{19072} == 1) {
		quest::say("Ahhh, finally...");
		quest::depop();
		quest::spawn2(30134,0,0,$x,$y,$z,$h); #Miragul 
		quest::depop();
	}  
}

sub EVENT_ATTACK {
	quest::say("Foolish mortal, you dare attack me?! Die!!");  
}

#END of FILE Zone:everfrost  ID:3233 -- Lich_of_Miragul 