sub EVENT_SAY { 
	if($text=~/fine then/i){
		quest::say("You have trespassed long enough on Sabertooth land!"); 
	}
}
#END of FILE Zone:everfrost  ID:51002 -- a_gnoll_guard 

