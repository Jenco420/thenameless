sub EVENT_ITEM { 
	if($itemcount{12221} == 1){
		quest::say("Growlll");
		quest::summonitem(12226); 
	}
}
#END of FILE Zone:everfrost  ID:30046 -- Iceberg 

