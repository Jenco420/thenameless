sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("Grrrrrr!!"); 
	}
}
#END of FILE Zone:everfrost  ID:30063 -- Snowflake 

