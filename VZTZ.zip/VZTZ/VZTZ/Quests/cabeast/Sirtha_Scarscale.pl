sub EVENT_SAY {
if($text=~/hail/i)
    {
    quest::say("Hello young traveler are you interested in the [armor] that I can make?");
    }
if($text=~/Rile?/i)
    {
    quest::say("Very good. We are smiths for the Crusaders of the Greenmist and I shall make [armor] for you. provided you prove your worth. Fail these simple tasks. and you shall not be worthy to bear the title of crusader!");
    }
if($text=~/helm?/i)
    {
    quest::say("The sarnak are a mockery of the Iksar. They are nothing more than beasts fit only to do our bidding! I require you to bring me the sword of one of their Order of Knights and the head of a sarnak berserker. These beasts have been attacking our patrols of late. I also require a stone called a ruby and a banded helm. Do this and I shall make a helm for you.");
    }
if($text=~/boots?/i)
    {
    quest::say("Cactus quills can be very lethal. I seek to work them into my new boots. Find me these quills. a pair of skeletal feet. an emerald of fire. and some banded boots so that I may start working on them. Why are you still here?! Begone!");
    }
if($text=~/gauntlets?/i)
    {
    quest::say("I currently have need of a complete skeletal hand. for the research I am conducting. I wish to study its properties and form so that I can make gauntlets befitting our station. I also require two rubies that holds stars within and some banded gauntlets to complete my ritual. Do that and the gauntlets are yours to keep.");
    }
if($text=~/vambraces?/i)
    {
    quest::say("The hideous Golra are hardy creatures. The tales indicate their ferocity almost matches our own. I wish to gain a trophy of one of these beasts. Bring me the skin of one. two blue sapphires. and banded sleeves. Then I shall give you these fine vambraces.");
    }
if($text=~/armor/i)
    {
    quest::say("I will make [helms], [gauntlets], [boots], and [vambraces]. My broodmate shall make the bracers, greaves, masks, and breastplate.");
    }
}
#END of FILE Zone:cabeast  ID:5758 -- Sirtha_Scarscale 

sub EVENT_ITEM {
#helm
if(plugin::check_handin(\%itemcount, 3053 => 1, 10035 => 1, 14822 => 1, 14826 => 1)) #Banded Helm, Ruby, Sarnak Berserker Head, Sarnak Knight's Sword
	{
	quest::summonitem(4968); #Dreadscale Helm
	quest::exp(1000);
	quest::say("Excellent! Take this as your reward.");
	}
#boots
elsif(plugin::check_handin(\%itemcount, 14828 => 1, 10033 => 1, 14823 => 1, 3064 => 1)) #Cactus Quills, Fire Emerald, Skeletal Feet, banded boots
	{
	quest::summonitem(4974); #Dreadscale Boots
	quest::exp(1000);
	quest::say("Excellent! Take this as your reward.");
	}
#gauntlets
elsif(plugin::check_handin(\%itemcount, 14825 => 1, 10032 => 2, 3062 =>1)) #Skeletal Hand, Star Ruby x 2, banded gauntlets
	{
	quest::summonitem(4972); #Dreadscale Gauntlets
	quest::exp(1000);
	quest::say("Excellent! Take this as your reward.");
	}
#vambraces
elsif(plugin::check_handin(\%itemcount, 14830 => 1, 10034 => 2, 3060 => 1)) #Golra Skin, Sapphire x 2, banded sleeves
	{
	quest::summonitem(4970); #Dreadscale vambraces
	quest::exp(1000);
	quest::say("Excellent! Take this as your reward.");
	}
#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}
