sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Welcome to Cabilis.  Capital of the new Iksar Empire.  One day all shall fear us as they once did.  One day. we shall take this entire orb and enslave it.  The wretched wurms shall not stop us this time."); }
}
#END of FILE Zone:cabeast  ID:5128 -- Trooper_Nagraz 

