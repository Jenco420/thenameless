sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("These are the sacred unholy grounds of the Crusaders of Greenmist and the Scaled Mystics.  If you do not belong to us. you must leave this temple at once or learn great suffering in the name of Cazic-Thule.");
	}
	if($text=~/greenmist/i) {
		quest::emote("appears surprised at your words. 'You know of Greenmist? The Unholy Khukri of Rile? We once had knowledge of this weapon, but when our great cities were destroyed in 1056 A.G., so, too, were all the great libraries. We lost all records. An explorer named [Argest] claimed to have found one library still intact. Pure babble.");
	}
	if($text=~/Who is Argest/i) {
		quest::say("Once a Lord of Pain, Argest is now a great explorer. No lizard has seen more of Kunark than he. He returned one season ago to tell tales of an [ancient library]. He said that he believed that there he would find a tome which would reveal the location of the ancient crusader weapon, Greenmist.");
	}
	if($text=~/ancient librar/i) {
		quest::say("There are many ancient libraries yet to be discovered. Our once great cities have been decimated, if not by our foes, then by nature itself. Within the outlands are many ruins which have yet to reveal themselves. We look forward to the discovery of these ruins by such explorers as Lord [Argest] the Great.");
	}
	if($text=~/Where is Argest/i) {
		quest::emote("becomes despondent at your question. 'Alas, our chance of locating Greenmist is lost as long as Argest remains missing. Reports have come in from the Legion's deep range patrols that he may be in the Frontier Mountain range. At least, that is where the patrol captain found Argest's walking staff. He might have been captured, killed or even digested!!");
	}
}

sub EVENT_ITEM { 
  if($class == 'Shadowknight') {
	if($itemcount{18205} == 1) {
		quest::say("Welcome into our brotherhood. Know you that our way is the way of pain. Do as we say and you shall climb the rungs of knighthood. Listen well to the Lords of Pain within this temple and follow the words of the hierophants, for Cazic-Thule speaks to us through them. Take this khukri. It is the chosen weapon of the Crusaders and can deliver great pain unto our foes. Go now and learn our ways. Seek out Lord Gikzic.");
		quest::summonitem(5120);
		quest::exp(100);
	}
	elsif($itemcount{18051} == 1 && $itemcount{5126} == 1) {
		quest::say("You have done as instructed. You are wise to hand this tome to me. It could bring you nothing more than insanity. As your reward, you shall have the squire's khukri. Soon you shall wield the knight's khukri, but that is for another Lord of Pain to decide.");
		quest::summonitem(5128);
		quest::exp(10000);
	} else {
		quest::emote("You are not worthy of this quest!");
		plugin::return_items(\%itemcount);
	}
  } else {
     quest::emote("You are not worthy of this quest!");
	 plugin::return_items(\%itemcount);
  }
}
#END of FILE Zone:cabeast  ID:87 -- Arch_Duke_Xog  BY: Jaxx

