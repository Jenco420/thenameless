sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Do you come to me empty handed. knave?  Did you lose your pike?"); }
}
#END of FILE Zone:cabeast  ID:782 -- Crusader_Zixo 

