sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Do not bother me unless you wish to join the chain gang.  Now go away or I shall have my slaves chop you as they chop this granite!"); }
}
#END of FILE Zone:cabeast  ID:5017 -- The_Toilmaster 

