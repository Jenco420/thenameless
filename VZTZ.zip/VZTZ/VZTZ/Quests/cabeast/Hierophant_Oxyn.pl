sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("Greetings. and may the pain of the ancients guide you.  You have come to us for guidance. have you not?  We are the Hierophants of Cabilis and we guide the young Scaled Mystics.  All petitioners shall speak with me of [temple tasks].");
	}
	if($text=~/what temple tasks/i){
		quest::say("The Temple of Terror requires all young Scaled Mystics to [perform daily tasks].  The tasks are necessary to the upkeep of our order as well as that of our brothers. the Crusaders of Greenmist.");
	}
	if($text=~/i whant to perform daily tasks/i){
		quest::say("We require many components for various rituals.  Take this component mortar and fill it with the following items - foraged [mud crabs]. two small mosquito wings and one portion of bone chips.  You must then use the pestle and combine all the components.  When you have a full component mortar. you may return to me and I shall pay you your wages. but most importantly. you shall prove your devotion to the Scaled Mystics.");
	}
	if($text=~/what mud crabs/i){
		quest::say("Mud crabs are tiny crustaceans which live along the mudcaked shores of the Lake of Ill Omen.  You can forage for them and find a handful of them at a time.");
	}
	if($text=~/liquid/i){
		quest::say("The bottle contains deklium in a liquid solution. The metal of prophecy has been determined to rest in a mass of living earth. Our scholars have written of a mass of ore that fell from the heavens. This ore was used in the creation of a blade of our father, Rile. We have been filled with visions of this blade. I have seen it in the hands of our Crusaders as they march towards the new age of Greenmist! Seek out the corrupted earth that guards the interlopers. We have an alchemist near there. He will be able to use the deklium to determine which golem contains the metal. Take care to go in force. I sense that there will be a battle.");
	}
}

sub EVENT_ITEM {
	if($itemcount{3895} == 1){
		quest::emote("Hierophant Oxyn takes the note and begins to howl into the air!");
		quest::say("The visions are true! The new prophecy begins today, Crusader.");
		quest::emote("the mystics growls with pleasure. He quickly turns and takes a bottle of murky liquid from one of his potion bags and hands it to you.");
		quest::say("Take this and keep it safe. Our visions have told of this day. We have been able to learn of the metal of prophecy. This liquid will help us to locate it's true resting place!");
		quest::summonitem(3892);
		quest::exp(500);
	} elsif($itemcount{3886} == 1) {
		quest::emote("holds the ore in his hands and begins to chant. His eyes go white as he raises the chunk of ore above his head. He lowers his arms and shakes his head for a moment. His eyes return to their normal state as they focus on you. The shaman hands you the ore and says, 'Seek out the creator of Rile's blade. He is still on this plane. I have felt his torment. Take this note to Librarian Zimor. He learned a great deal from the tome and can instruct you further.");
		quest::summonitem(3893);
	} else {
		quest::say("I have no need of this, You can have it back.");
		plugin::return_items(\%itemcount);
	}
}