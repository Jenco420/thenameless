sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail Broodling! When you walk the halls of this tower. you should always display the status that you have earned within our ranks.  It brings me pride to see the might of the brood displayed by one such as you while I reflect here in the tower.  Do you have the tool of your caste with you at this time?"); }
}
#END of FILE Zone:cabeast  ID:4782 -- Squire_Gristle 

