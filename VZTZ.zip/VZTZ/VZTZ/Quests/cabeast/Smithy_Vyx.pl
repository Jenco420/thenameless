sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("I have heard of a great piercing weapon created to pierce the skin of the wurms.  Such a weapon would be quite devastating!"); }
}
#END of FILE Zone:cabeast  ID:4669 -- Smithy_Vyx 

