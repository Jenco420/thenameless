sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Leave me in peace $name. I have little desire for company now.  The Faceless sends visions to me that may hold the fate of our race in sway."); }
}
#END of FILE Zone:cabeast  ID:5761 -- Hierophant_Granix 

