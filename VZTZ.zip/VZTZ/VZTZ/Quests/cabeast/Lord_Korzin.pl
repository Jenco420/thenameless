sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("What is it you seek?  Eternal suffering?");
	}
	if($text=~/i seek eternal suffering/i){
		quest::say("Then follow the words of Cazic-Thule and may his blessed curses rain upon your soul as they shall on all of his faithful servants.");
	}
	if($text=~/skull of torture/i) {
		quest::say("You were sent to me. You must be the squire who found the ancient tome, 'The Origins of Pain'. I can use a talented crusader such as yourself. In my dreams, Cazic-Thule has spoken to me. He instructed me to seek out the 'Skull of Torture' which was last reported to be within the torture tower of the ancient Lord of Pain, Kurn. Will you [accept the calling]?.");
	}
	if($text=~/accept the calling/i) {
		quest::say("As if you had a choice. Seek out the tower of Kurn and find the Skull of Torture. You should be able to easily recognize this skull as it glows with the power of Cazic Thule. Return it to me with your squire's khukri and I shall reward you with the knight's khukri. Go at once.");
	}
}

sub EVENT_ITEM {
  if($class == 'Shadowknight') {
	if($itemcount{12401} == 1 && $itemcount{5122} == 1) {
		quest::say("Excellent work! You are no squire. You are now a knight of the crusaders. Your next step shall be zealot. And every zealot wields a magical khukri.");
		quest::summonitem(5123);
		quest::exp(2000);
	} else {
		quest::emote("You are not worthy of this quest!");
		plugin::return_items(\%itemcount);
	}
  } else {
     quest::emote("You are not worthy of this quest!");
	 plugin::return_items(\%itemcount);
  }
}
#END of FILE Zone:cabeast  ID:106107-- Lord_Korzin BY: Jaxx

