sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("I am a Drill Master of the Legion of Cabilis.  I have no time for idle chitchat.  Be off if you were not summoned to this fortress!  Find that guild which was chosen for you as an egg.");
	}
}

sub EVENT_ITEM {
	if ($itemcount{18203} == 1) {
		quest::say("Thanks.");
		quest::summonitem("5130");
		quest::exp("100");
	} else {
		plugin::try_tome_handins(\%itemcount, $class, 'Monk');
		plugin::return_items(\%itemcount);
	}
}
