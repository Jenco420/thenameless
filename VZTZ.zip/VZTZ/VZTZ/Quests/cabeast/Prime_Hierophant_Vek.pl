sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Praise to the ancients. my friend!  There is much suffering to be given unto the world.  I am the Prime Hierophant of the Temple of Terror.  Through me and my fellow priests flows the wisdom of our ancestors."); }
}
#END of FILE Zone:cabeast  ID:3991 -- Prime_Hierophant_Vek 

