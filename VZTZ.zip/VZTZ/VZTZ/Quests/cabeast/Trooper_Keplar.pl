sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You want to be like Trooper Keplar?  Who does not?  You must first be summoned to rebirth within Fortress Talishan.  If you have not. then you can not be like this grand one."); }
}
#END of FILE Zone:cabeast  ID:5119 -- Trooper_Keplar 

