sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Going scouting in the wilds of Kunark?  Wait!!  Before you do. buy all you need from me.  I am a survival outfitter.  You most assuredly will need a water extractor and purification tablets.  If not those. then perhaps a poncho or machete to protect you from the elements and chop through the bush."); }
}
#END of FILE Zone:cabeast  ID:3018 -- Klok_Dytar 

