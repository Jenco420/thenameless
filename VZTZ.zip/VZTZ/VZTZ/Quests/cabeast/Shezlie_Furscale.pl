sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Be careful around here. $name. Injured broodlings are no use to anyone. Many of these structures are yet unstable and could fall at any time."); }
}
#END of FILE Zone:cabeast  ID:5756 -- Shezlie_Furscale 

