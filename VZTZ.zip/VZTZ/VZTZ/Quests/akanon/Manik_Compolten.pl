sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings, young one. I am Manik Compolten, High Watchman. Are you a [new warrior] or an [experienced fighter]?");
}
if($text=~/i am a new warrior/i){
quest::say("It is always good to see new blood amongst the Gemchoppers. I have a small task for you. Take this keycard. I will give you only one at a time. Use each to obtain blackboxes for the C series clockworks. I am sure you are familiar with the clockworks. When you are done, bring them all to me. Let me know if you need another keycard.");
quest::summonitem("13844");
}
if($text=~/i am an experienced fighter/i){
quest::say("Good.  I require your talents to destroy rogue clockworks.  After we sent the clockworks to destroy the Asylum of the Mad we found some of the clockworks went haywire and never returned.  We must destroy them, not for the safety of the people, but to keep our technology from falling into the hands of any other nation. Go to the Steamfont Mountains and return their rogue blackboxes to me."); }
}

sub EVENT_ITEM {
 #do all other handins first with plugin, then let it do disciplines
 plugin::try_tome_handins(\%itemcount, $class, 'Warrior');
 plugin::return_items(\%itemcount);
}
#END of FILE Zone:akanon  ID:55155 -- Manik_Compolten 
