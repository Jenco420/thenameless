sub EVENT_SAY { 
  if($text=~/Hail/i){
    quest::say("Yoo leave me 'lone!"); 
  } 
}

sub EVENT_ITEM {
  if ($itemcount{20673} == 1) {
    quest::emote("snatches the note from your hand and rips it open with his large hands.");
    quest::say("You take dis to Kargek. He want!");
    quest::ding();
    quest::exp("1000");
    quest::summonitem("20674"); #Tiny Lute
  } else {
    plugin::return_items(\%itemcount);
  }
}