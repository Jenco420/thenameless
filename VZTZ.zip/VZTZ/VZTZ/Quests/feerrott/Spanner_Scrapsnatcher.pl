sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You know. you can go greet yourself.  Converse with yourself and then see yourself off while you're at it.  I've had enough of this place. To be honest. I've just thought about it and I think that I've had quite enough of you as well.  So mate. unless you're holding my bag of fame and fortune... as promised to me last week by our huge headed friend over there...  I think that it would be best if you shambled off.  Please feel free to take the Erudite with you."); }
}
#END of FILE Zone:feerrott  ID:47130 -- Spanner_Scrapsnatcher 

