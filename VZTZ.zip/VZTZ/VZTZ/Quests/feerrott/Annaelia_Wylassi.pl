sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("If you have nothing other than a hail to offer me you best move along. I need concentration to study these odd bones that I unearthed.  Funny thing about them though. they seem to resonate a hum.   Quite unusual. you probably aren't interested in that though."); }
}
#END of FILE Zone:feerrott  ID:47154 -- Annaelia_Wylassi 

