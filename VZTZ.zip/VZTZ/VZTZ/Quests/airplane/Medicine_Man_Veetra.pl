#Medicine Man Veetra for Shaman Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Shaman')){  quest::say ("Good day to you, $name. Are you a shaman of [much experience]?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Shaman, begone!");
}
if ($text =~/experience/i && ($class eq 'Shaman')){  quest::say ("Then welcome to the tests of the medicine man. I have two tomes, each tells of a shaman of great accomplishment. They are [Gina McStargan] and [Ooga]. Simply tell me the name of the shaman you want to be tested by.");  }

	#Summon Gina MacStargan
	if(($text=~/Gina/i) && ($class eq "Shaman")) {quest::say("I shall summon them for you");
	quest::spawn2(71100,0,0,631.9,1401.9,-766.9,129.8);
	quest::depop();
	}

	#Summon Ooga
	if(($text=~/Ooga/i) && ($class eq "Shaman")){quest::say("I shall summon them for you");
	quest::spawn2(71101,0,0,653.4,1399.0,-766.9,129.8);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71044 -- Medicine Man Veetra