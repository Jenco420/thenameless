my $Azarack;
my $Vanquishers;
my $HarvesterCheck;

sub EVENT_SPAWN {
	$Azarack = 0;
	$Vanquishers = 0;
	$HarvesterCheck = 0;
}

sub EVENT_SIGNAL {
	if($signal eq 1) {
		quest::settimer("Island1", 30);
	}
	if($signal eq 2) {
		quest::settimer("Island2", 30);
	}
	if($signal eq 3) {
		if ($HarvesterCheck == 0) {
			$HarvesterCheck = 1;
			quest::settimer("Island4", 4800);
		}
	}
	if($signal eq 4) {
		$Azarack += 1;
		if ($Azarack == 9) {
			quest::spawn2(71059,0,0,-674.26,-334.68,-328.23,$h); #Protector of Sky
			$Azarack = 0;
		}
	}
	if ($signal eq 5)  {
		$Vanquishers += 1;
		if ($Vanquishers > 2) {
			quest::signalwith("71013","1","1");
		}
		quest::shout($Vanquishers);
	}
	if($signal eq 98) {
		if ($Vanquishers > 0) {
			$Vanquishers -= 1;
		}
	}
	if($signal eq 99) {
		if ($Azarack > 0) {
			$Azarack -= 1;
		}
	}
}

sub EVENT_TIMER {
	if($timer eq "Island1") {
		quest::spawn2(71032,0,0,493,1370,-646,24);
		quest::stoptimer("Island1");
	}
	if($timer eq "Island2") {
		quest::spawn2(71059,0,0,-570,-140,-314,128);
		quest::stoptimer("Island2");
	}
	if($timer eq "Island4") {
		$HarvesterCheck = 0;
		quest::spawn2(71078,0,0,-1540.4,660.72,126.52,$h);
		quest::stoptimer("Island4");
	}
}