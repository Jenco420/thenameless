sub EVENT_SAY{
	if($text=~/i am prepared/i){
		quest::attack($name);
	}
}
