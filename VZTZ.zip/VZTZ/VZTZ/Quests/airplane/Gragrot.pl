#Gragrot for Shadowknight test of Bash, Smash, Slash

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Hail!  So you think you are a mighty Knight of Shadows?  We must test these skills. [Are you ready] to begin the test?  Or do you think you have already proof of your deeds?");
        }
}

#start tests
if ($text =~/Ready/i)
	{
        quest::say ("Great, let us waste no more time!  I offer to you three challenges,  [Bash], [smash], or [slash]?  What do you wish to be tested in?");
        }

#test of Bash
elsif ($text =~/Bash/i)
	{
        quest::say ("Gragrot like bashin. Gragrot say you like bashin too! Give Gragrot an Ebon Tessera, a Sphinx Eye Opal, and a Finely Crafted Amulet. Gragrot then give you Sphinx Eye Amulet.");
        }

#Test of Smash
elsif ($text =~/Smash/i)
	{
        quest::say ("Gragrot wants you smashin. Smash, smash, and return a Copper Disk, a Small Sapphire, and a Silvery Ring. Then Gragrot give you Djinni's Finger Ring.");
        }

#Test of Slash
elsif ($text =~/Slash/i)
	{
        quest::say ("Gragrot see you is powerful, but Gragrot wonders if you is good at Slashin. Gragrot says return with a Diaphanous Globe, a piece of dried leather, and a Finely Woven Cloth Belt. Gragrot then give you pegasus hide belt.");
        }
}

sub EVENT_ITEM
{
#test of Bash turn in
if(plugin::check_handin(\%itemcount, 20997 => 1, 20929 => 1, 20998 => 1)) #Sphinx Eye Opal, Ebon Tessera, Finely Crafted Amulet
	{
	quest::summonitem("27705"); #Amulet of the Sphinx Eye
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of Smash turn in
elsif(plugin::check_handin(\%itemcount, 20936 => 1, 20999 => 1, 20700 => 1)) #Copper Disc, Small Sappire, Silvery Ring
	{
	quest::summonitem("27706"); #Crimson Ring of the Djinni
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Slash turn in
elsif(plugin::check_handin(\%itemcount, 20943 => 1, 20701 => 1, 20702 => 1)) #Diaphanous Globe, Dried leather, Finely woven cloth belt
	{
	quest::summonitem("2704"); #Pegasus-Hide Belt
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71063 -- Gragrot