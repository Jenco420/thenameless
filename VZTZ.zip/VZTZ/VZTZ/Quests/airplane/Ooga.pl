#Ooga for Shaman tests of Shrink, Snake, the Witch Doctor

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Euh? You come see Ooga about shaman tests? Me can test in [shrink], the [snake], or [witch doctor]! What yuz want to test in?");
        }


#Test of Shrink
elsif ($text =~/shrink/i)
	{
        quest::say ("Ohh! Dat gud tes, me know cuz me did It. Me had get a Efreeti War Club, Djinni Statuette, sum Corrosive Venom an sum Wooden Bands. Was hard for Ooga, me took long to get dem. Yuz give all to me at sam time me give yuz what me got.");
        }

#Test of Snake
elsif ($text =~/snake/i)
	{
        quest::say ("Mmm, tes of snake not too bad, me did It an still alive. When me did It, me got Emerald Spiroc Feather, Bixie Essence, an Spiritualists Ring. Me get gud stuff for dat. Yuz giv me stuff all at once an me give to yuz what me got.");
        }

#Test of the Witch Doctor
elsif ($text =~/witch doctor/i)
	{
        quest::say ("Oh! Now yuz got In da big mojo, me had big hard time wit dis one. Me got In lot of trouble when me got Efreeti War Maul, Thickened Nectar, Fire Sky Ruby an Symbol Of Veeshan. Yuz giv to me, Me be easy on yuz an giv prize me got.");
        }
}

sub EVENT_ITEM {
#Test of Shrink turn in
if (plugin::check_handin(\%itemcount, 20845 => 1, 20955 => 1, 20842 => 1, 20841 => 1)) #Efreeti War Club, Djinni Statuette, Corrosive Venom, Wooden Bands
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("27729"); #Warhammer of the Wind
	quest::exp(100000);
	}

#Test of Snake turn in
elsif(plugin::check_handin(\%itemcount, 20962 => 1, 20843 => 1, 20844 => 1))  #Emerald Spiroc Feather, Bixie Essence, Spiritualist's Ring
	{
	quest::summonitem("27730"); #Vermilion Sky Ring
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of the Witch Doctor turn in
elsif(plugin::check_handin(\%itemcount, 20846 => 1, 20969 => 1, 20738 => 1, 20847 => 1))  #Efreeti War Maul, Thickened Nectar, Fire Sky Ruby, Symbol of Veeshan
	{
	quest::summonitem("2322"); #Garduk (this item needs to be added to the database)
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71101 -- Ooga