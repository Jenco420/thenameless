#Thalik Silenthand for Rogue Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Rogue')){  quest::say ("Greetings, $name.  Do you believe you are a [great rogue]?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Rogue, begone!");
}
if ($text =~/rogue/i && ($class eq 'Rogue')){  quest::say ("Choose who you wish to begin with, [Rayne] or [Kendrick]");  }

	#summon Rayne
	if(($text=~/Rayne/i) && ($class eq "Rogue")) {quest::say("I shall summon them for you");
	quest::spawn2(71061,0,0,563.3,1372.6,-766.9,63.4);
	quest::depop();
	}

	#summon Kendrick
	if(($text=~/Kendrick/i) && ($class eq "Rogue")){quest::say("I shall summon them for you");
	quest::spawn2(71068,0,0,660.7,1388.9,-766.9,192.6);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71051 -- Thalik Silenthood