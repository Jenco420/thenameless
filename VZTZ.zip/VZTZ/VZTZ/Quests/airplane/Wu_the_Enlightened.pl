#Wu_The_Enlightened for Monk tests of fists, tranquility, tears

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Greetings Warrior of mind and body. To prove your worth to me, you must complete a test. Which test do you wish to take? I will permit you to take the test of [Fists], [Tranquility], or [tears].?");
        }

#test of fists
if ($text =~/fists/i)
	{
        quest::say ("A monk must know when to use his or her fists, and when to use ones mind. You must decide in this endevour, which you shall use. Return to me, once you have found them, a pair of Brass Knuckles, a White Spiroc Feather, an Emerald Amethyst, and a Nebulous Sapphire.");
        }

#test of tranquility
elsif ($text =~/tranquility/i)
	{
        quest::say ("Ah, the test of tranquility. Only the tranquil monk can achieve enlightenment. Are you such an individual? Time shall tell. Retrieve these items for me. Bring an Aged Nectar, a Writ of Quellious, and a Glowing Diamond and we shall asses your ability.");
        }

#test of tears
elsif ($text =~/tears/i)
	{
        quest::say ("he test of tears involves knowing when to release, and when to provide a shoulder for another. Bring me a Spiroc Statuette, a Spiroc Talon, and a Silken Wrap. I will teach you the way.");
        }
}

sub EVENT_ITEM
{
#test of fists turn in
if(plugin::check_handin(\%itemcount, 20803 => 1, 20960 => 1, 20801 => 1, 20802 => 1)) #brass knuckles, white spiroc feather, ethereal amethyst, nebulous sapphire
	{
	quest::summonitem("11690"); #Wu's Tranquil Fists
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#test of tranquility  turn in
elsif(plugin::check_handin(\%itemcount, 20967 => 1, 20804 => 1, 20829 => 1)) #Aged Nectar, Decree of Quellious, Glowing Diamond
	{
	quest::summonitem("11698"); #Golden Sash of Tranquility
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of tears turn in
elsif(plugin::check_handin(\%itemcount, 20954 => 1, 20799 => 1, 20800 => 1)) #Spiroc Statuette, Spiroc Talon, Silken Wrap
	{
	quest::summonitem("1283"); #Ton Po's Shoulder Wraps
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71097 -- Wu the Enlightened