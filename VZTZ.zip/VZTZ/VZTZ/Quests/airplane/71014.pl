#spiroc walker
sub EVENT_SPAWN
{
$Walker = 1;
}

sub EVENT_SIGNAL {

if($signal eq 1) 
	{
	$Walker -= 1;
	}
	
if($signal eq 99) 
		{
	if ($Walker < 1) {
		$Walker += 1;
		}
	}
	
}

sub EVENT_DEATH
{
if ($Walker == 1)
	{
        quest::spawn2(71014,17,0,1097.50,-522.24,484.76,$h); #spawn Walker again if vanquisher is up
        }
}

