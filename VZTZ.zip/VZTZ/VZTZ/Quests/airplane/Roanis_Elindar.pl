#Deric Lennox Cleric test of Resolution, the weak, and theurgy

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("reat, let us waste no more time! I offer to you three challenges. [Summoning], [Interpretation], and [Displacement].  Please choose one of these.");
        }

#Test of Displacement
elsif ($text =~/Displacement/i)
	{
        quest::say ("Displacement it is. Proceed upward through the sky and return to me some Sweet Nectar, the Crown of Elemental Mastery, a Large Opal, and Djinni's Stave. This will prove your abilities to me and I will reward you with the Staff of Elemental Mastery.");
        }

#Test of interpretation
elsif ($text =~/interpretation/i)
	{
        quest::say ("Interpretation it is. Proceed upward through the sky and return to me a Carmine Spiroc Feather, a Blood Sky Amethyst, and a Golden Efreeti Ring. This will prove your abilities to me and I will reward you with the Duennan Shielding Ring.");
        }

#Test of summoning
elsif ($text =~/summoning/i)
	{
        quest::say ("Summoning it is. Proceed upward through the sky and return to me a Harpy Statuette, a Finey Woven Cloth Amice, and a Large Diamond. This will prove your abilities to me and I will reward you with a Drake Hide Amice.");
        }
}

sub EVENT_ITEM
{

#Test of Displacement turn in
if(plugin::check_handin(\%itemcount, 20966 => 1, 20764 => 1, 20766 => 1, 20765 => 1)) #Sweet nectar, Crown of Elemental mastery, Large Opal, Djinni Statue
	{
	quest::summonitem("11568"); #Staff of elemental mastery: air
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of interpretation turn in
elsif(plugin::check_handin(\%itemcount, 20959 => 1, 20762 => 1, 20763 => 1)) #Carmine Spiroc Feather, Blood Sky Amethyst, Golden Efreeti Ring
	{
	quest::summonitem("11687"); #Duennan Shielding Ring
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of summoning turn in
elsif(plugin::check_handin(\%itemcount, 20925 => 1, 20760 => 1, 2061 => 1)) #Harpy Statuette, Finely woven cloth amice, Large diamond
	{
	quest::summonitem("2708"); #Drake-Hide Amice
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71091 -- Roanis Elindar