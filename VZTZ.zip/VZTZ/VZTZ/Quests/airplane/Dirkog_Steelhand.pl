#Dirkog Steelhand for Paladin epic & test of spirit

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Leave me be, ye orc kissin' [son of Innoruuk!]");
        }

#Paladin epic
if ($text =~/not a son of Innoruuk/i)
	{
        quest::say ("Eh? Ye say that ye ain't one o' the cursed dark elf dogs? Well then, laddie, are ye ready to be [tested in spirit] or are ye here fer [something else??]");
        }

#Paladin Epic
elsif ($text =~/something else/i)
	{
        quest::say ("Eh, lad? What was that? Ye wish to hear o' holy swords? Well, lad, I ain't the one ye be needin' t' talk to!");
        }

#Paladin Epic
elsif ($text =~/talk to/i)
	{
        quest::say ("A follower o' the water god he be, an' one o' the most powerful holy knights e'er to walk Norrath. His name be [Inte Akera], an' he kin tell ye what ye be wantin' t' know.");
        }

#Paladin Epic
elsif ($text =~/Inte Akera/i)
	{
        quest::say ("Ah, I see ye wish t' speak with him! Why didn't ye say that earlier, laddie? It would've saved ye some trouble! If ye wish to speak with him, ye must [donate] some spare change t' me ale.. er, t' me holy crusade fund! Well, lad, what d' ye say?");
        }

#Paladin Epic
elsif ($text =~/donate/i)
	{
        quest::say ("Eh? Oh, 500 platinum will be plenty, laddie!");
        }

#Test of Spirit
elsif ($text =~/spirit/i)
	{
        quest::say ("Well then! You best go out an get me a silvery girdle, a diaphanous globe, an a ivory sky diamond! Come on back with them and you'll get a nice belt.");
        }
}

sub EVENT_ITEM
{
if($platinum == 500)
	{
	quest::say("Thank ye, laddie! He's awaitin' ya up top!");
	quest::spawn2(71109,0,0,-579.52,767.83,174.04,63.5);
	quest::depop();
        }

#test of spirit turn in
elsif(plugin::check_handin(\%itemcount, 20868 => 1, 20943 => 1, 20869 => 1)) #Silvery Girlde, Diaphanous Globe, Ivory Sky Diamond
	{
	quest::summonitem("2716"); #Girlde of Faith
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71107 -- Dirkog_Steelhand