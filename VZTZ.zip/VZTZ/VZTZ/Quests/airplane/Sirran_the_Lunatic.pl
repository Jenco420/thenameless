$whichIsland = 1; # we default to island 1

sub EVENT_SPAWN {
quest::settimer("depop",800);
}
sub EVENT_SAY{
	if( $whichIsland == 1 ){
		&islandOne;
	}
	elsif( $whichIsland == 2 ){
		&islandTwo;
	}
	elsif( $whichIsland == 3 ){
		&islandThree;
	}
	elsif( $whichIsland == 4 ){
		&islandFour;
	}
	elsif( $whichIsland == 5 ){
		&islandFive;
	}
	elsif( $whichIsland == 6 ){
		&islandSix;
	}
	elsif( $whichIsland == 7 ){
		&islandSeven;
	}
}

sub islandOne {
	if($text=~/Hail/i){
		quest::say("Ehem! What? Oh, hello there! Sirran be my name. Yes? So, come to the Plane of Sky, have you? Killed all my fairies! Hah! So! Do you wish to know how to traverse this plane? Or should I just go away? I know much about this plane. You would do well to listen!" );
	}
	elsif($text=~/traverse this plane/i){
		quest::say("Ahah! Wise you are and tell you I will. Hrm? Don't have wings, do you? Fairies have swords! Fairies stole my lucky feet! Hand me them, one by one, and be in for a treat! Haha!" );
	}
}

sub islandTwo {
	if($text=~/Hail/i) {
		quest::say("Ah!  Come far you have!  You are all crazy!  I like it! Swords spin no more! Spin, spin.  Unlucky they were! I thought them [vain]!");
	}
}

sub islandThree {
	if($text=~/Hail/i) {
		quest::say( "What! Die already! Come so far. Can't you see I am cold! Give me a cloak or something! Bah! You don't look the type to give anything! Be off with you, then!");
	}
}

sub islandFour {
	if($text=~/Hail/i){
		quest::say( "You again! Aren't you dead yet? Well, give me the token items you got, and move on you will. Maybe. Oh! Wait!! Rings go on fingers, yes they do! Gimme a ring and I'll help you!" );
	}
}

sub islandFive {
	if($text=~/Hail/i){
		quest::say( "Children, run to the wall and give the deputies some miIk. Oh, I almost forgot. Give me your trinkets, or give me death!" );
	}
}

sub islandSix {
	if($text=~/citanuL eht narriS, liaH/i){
		quest::say("Lortap llaw taerg eht fo lahsram, Narris lahsram ma I. Flesym ecudortni ot em wolla. Sgniteerg.");
	}
	elsif( $text =~ /llaw eht htiw eno I ma/i ){
		quest::say("Kcul doog! Ouy rof ydaer si erips eht fo retsis eht won, sdik boj doog.");
		quest::spawn(71076, 0, 0, -950, -1050, 1050 );
	}
}

sub islandSeven {
	if($text=~/Hail/i){
		quest::say( "Nyah! The tears are welling up in my eyes! I am so proud. I think of you as if I were your father! Sniff. Sniff. Give me Veeshan, and I give you death." );
	}
}

sub EVENT_ITEM {
	#Miniature Sword
	if($itemcount{20920} == 1) {
		quest::say("These are the keys!  Use them well!  Hold them in your hand and touch " .
         "them to the runed platforms!  Guide you they will!  Hah!  The last to go, " .
         "must tell me so, or be in for a [hassle].  If there is a hassle I will go!!");
		quest::summonitem("20911"); #Key of Swords
	} 
	#Lost rabbit's foot
	elsif($itemcount{20921} == 1) {
		quest::say("These are the keys!  Use them well!  Hold them in your hand and touch them to the runed platforms!  Guide you thy will!  Hah!  The last to go, must tell me so, or be in for a [hassle]!  If there's a hassle, I will go!");
		quest::summonitem("20912"); #Key of the Misplaced
	}
	#Broken Mirror
	elsif($itemcount{20922} == 1) {
		quest::say("You move fast, you crazy kids!  Keep going! Prod you I will!  Stuck here I have been!  Oh!  Let me know when you are [done] or this will be no fun!  Haha!");
		quest::summonitem("20913"); #Key of Beasts
	}
	#Animal Figurine
	elsif($itemcount{20923} == 1) {
	    quest::say( "Always want something for nothing? Oh yes, you gave me something! Here you go! Take this! Used one you have. [Teleport] away you will! Let me know, or no kill! Haha!" );
		quest::summonitem("20914");
	}
	#Bird Whistle
	elsif($itemcount{20924} == 1) {
		quest::say( "What is this? Bah! Take that! And this! What was I thinking? I was thinking you had best let me know when you use those teleporters. Just say, [Icky Bicky Barket]. Aye, that is what I was thinking." );
		quest::summonitem("20915"); #Avian Key
	}
	#Noise Maker
	elsif($itemcount{20925} == 1) {
		quest::say( "Phew! These are heavy. Well, not really. I'm sure I don't have to remind you to remind me when you are [leaving]." );
		quest::summonitem("20916"); #Key of the Swarm
	}
	#Dull Dragon Scale
	elsif($itemcount{20926} == 1) {
		quest::say( "Dnib a ni era uoy ro esarhp eht yas dna yrruh!! Sruoy era syek eht dna romra em evig. Erom on gnits seixib eht ahahahahah!" );
		quest::summonitem("20917"); #Key of Scale
	}
	#Replica of the Wyrm Queen
	elsif($itemcount{20927} == 1) {
		quest::say( "Not too much farther. I spit on thee knave! Ehem. Take these. Go on! Make your fortunes. No one cares about Narris. I mean Sirran. Hah! See if I care what you think! Oh, when did you say you were [leaving]?" );
		quest::summonitem("20918"); #Veeshan's Key
	}
}


sub EVENT_AGGRO {
	quest::shout( "What?! Now you've done it! The bunnies are angry! ANGRY I TELL YOU!" );
}


sub EVENT_SPAWN {

	local $z = $npc->GetZ();
   
	if( $z > -300 ) { $whichIsland = 2; }
	if( $z > -100 ) { $whichIsland = 3; }
	if( $z > 100 ) { $whichIsland = 4; }
	if( $z > 350 ) { $whichIsland = 5; }
	if( $z > 700 ) { $whichIsland = 6; }
	if( $z > 950 ) { $whichIsland = 7; }

	quest::settimer( $mobid, 900 );
}

sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
