#Josin_Faithbringer For Cleric Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Cleric')){  quest::say ("Greetings $name.  Do you feel that you are ready [to be tested]?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Cleric, begone!");
}
if ($text =~/to be tested/i && ($class eq 'Cleric')){  quest::say ("Choose who you wish to begin with, [Allan Hartman] or [Deric Lennox]");  }

	#summon Allan Hartman
	if(($text=~/Allan/i) && ($class eq "Cleric")) {quest::say("I shall summon them for you");
	quest::spawn2(71087,0,0,660.7,1368.4,-766.9,192.6);
	quest::depop();
	}

	#summon Deric Lennox
	if(($text=~/Deric/i) && ($class eq "Cleric")){quest::say("I shall summon them for you");
	quest::spawn2(71108,0,0,660.7,1388.9,-766.9,192.6);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71084 -- Josin Faithbringer