#Sarkis_Ebonblade For Shadowknight Tests

sub EVENT_SAY {
	if($class eq 'Shadowknight') {
		if ($text =~/Hail/i) {  
			quest::say ("Greetings young Shadowknight. Are you here [to be tested]?");  
		}
		if ($text =~/to be tested/i) {  
			quest::say ("Then, tested you will be! There are many tests, choose one carefully: [Test of Bash], [Test of Disempowerment], [Test of Envenoming], [Test of Necropotence], [Test of Slash] or [Test of Smash].");  
		}
		if ($text =~/disempowerment/i) {  
			quest::say ("To complete the Test of Disempowerment, bring me the following treasures: a Blood Sky Emerald from the Spiroc Guardian, a Griffon Statuette from Various Entities in the Plane and the Rusted Pauldrons from Bazzt Zzzt.");  
		}	
		if ($text =~/envenoming/i) {  
			quest::say ("To complete the Test of Envenoming, bring me the following treasures: an Efreeti War Shield from Noble Dojorn, a Dark Spiroc Feather from the Spirocs and an Obsidian Shard from a Bzzazzt.");  
		}
		if ($text =~/necropotence/i) {  
			quest::say ("To complete the Test of Necropotence, bring me the following treasures: an Efreeti War Axe from Noble Dojorn, a Dulcet Nectar from a Bzzazzt, a Bloodstained Hilt from Various Drakes in this Plane and a Blood Sky Ruby from the Eye of Veeshan.");  
		}
	} else {
		if($text =~/Hail/i){  
			quest::say ("You are not a Shadowknight, begone!"); 
		}
	}
}           

sub EVENT_ITEM {
	if(($itemcount{20703} == 1) && ($itemcount{20950} == 1) && ($itemcount{20704} == 1)) {
		quest::summonitem("4322"); #Blood Sky Face Plate
		quest::exp(100000); 
		quest::say("Well done, $name. Here is your reward."); 
	} 
	elsif(($itemcount{20705} == 1) && ($itemcount{20957} == 1) && ($itemcount{20706} == 1)) {
		quest::summonitem("11678"); #Obtenebrate Mithril Guard
		quest::exp(100000); 
		quest::say("Well done, $name. Here is your reward."); 
	} 
	elsif(($itemcount{20711} == 1) && ($itemcount{20964} == 1) && ($itemcount{20712} == 1) && ($itemcount{20713} == 1)) {
		quest::summonitem("11679"); #Rheumguls
		quest::exp(100000); 
		quest::say("Excellent! Take this as your reward."); 
	} else {
		plugin::return_items(\%itemcount); 
	}
}
