#Fenalla Moonshadow: Druid Test of Nature, Druid Test of the Bee & Druid Test of the Eagle

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Children of the trees, friend and protector of nature. We the brothers and sisters to the wolves and bears. The call of the Great Pine has filled your heart and have found your way here to be tested. Do you wish to be [tested in Nature], the [art of the Bee], or the [way of the Eagle]?");
        }


#Test of Nature
elsif ($text =~/nature/i)
	{
        quest::say ("The test of Nature is the most difficult test a child of the Trees can undergo. Its completion would prove the Druid is truly one with all of nature. An Efreeti Scimitar, some Lush Nectar, a Fire Sky Ruby and a Storm Sky Opal are required. When you return all at once, the reward will be yours. Safe journey to you!");
        }

#Test of the Bee
elsif ($text =~/bee/i)
	{
        quest::say ("The test of the Bee you say? Very well, go forth and gain an Efreeti Statuette, a Wilder's Girdle and finally a piece of divine Honeycomb. Bring them all to me after you have them all and I shall give the just reward.");
        }

#Test of the Eagle
elsif ($text =~/eagle/i)
	{
        quest::say ("The test of the eagle is very difficult, and one must be as strong as the Great Pine to finish. For this test I shall need you to find a White-Tipped Spiroc Feather, some Acidic Venom, an Ethereal Ruby and finally a Spiroc Elders Totem. Return all four at once and the prize will be yours.");
        }
}

sub EVENT_ITEM {
#Druid Test of Nature turn in
if (plugin::check_handin(\%itemcount, 20739 => 1, 20738 => 1, 20965 => 1, 20740 => 1)) #Efreeti Scimitar, Fire sky ruby, Lush nectar, Storm spy opal
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("11683"); #Espri
	quest::exp(100000);
	}

#Druid Test of the Bee turn in
elsif(plugin::check_handin(\%itemcount, 20735 => 1, 20951 => 1, 20734 => 1))  #Divine Honeycomb, Efreeti Statuette, Wilder's Girdle
	{
	quest::summonitem("11684"); #Honeycomb Belt
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Druid Test of the Eagle turn in
elsif(plugin::check_handin(\%itemcount, 20736 => 1, 20737 => 1, 20867 => 1, 20958 => 1))  #Acidic Venom, Ethereal Ruby, Spiroc Elder's Totem, White-tipped Spiroc Feather
	{
	quest::summonitem("2322"); #Cloak of Leaves
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71086 -- Fenalla Moonshadow