#Gordon Treecaller for ranger test of Ranged Attack, Blade, Thunder

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Hello $name, I can only hope that my disturbance was necessary. Ahh, you seem to be decently adept with a blade. Would you like to be tested in the element of [thunder], the [blade], or the art of [ranged attack]?");
        }
}

#test of Ranged Attack
if ($text =~/ranged attack/i)
	{
        quest::say ("Many of the fools on Norrath don&rsquot realize how powerful a good bow can be. Many dread wolves have met their fate from my bow and you can have the same power if you can bring me back these items. Efreeti war bow, thickened nectar, a sphinx tallow, and a shimmering pearl.");
        }

#Test of the blade
elsif ($text =~/blade/i)
	{
        quest::say ("Very good choice, my blade is my best friend and yours will be as well if you can complete this task. Retrieve an efreeti long sword, an emerald spiroc feather, some bitter honey, and a circlet of brambles. Be careful with the honey, if it is tainted the blade will not come to life.");
        }

#Test of thunder
elsif ($text =~/thunder/i)
	{
        quest::say ("One of my greatest allies indeed. Thunder can be very powerful if used properly. Bring me a djinni statuette, a spiroc thunder totem, and a white gold earring. Then you will know the true power of nature.");
        }
}

sub EVENT_ITEM
{
#test of Ranged Attack turn in
if(plugin::check_handin(\%itemcount, 20861 => 1, 20969 => 1, 20862 => 1, 20863 => 1)) #Efreeti War Bow, Thickened Nectar, Sphinx Tallow, Shimmering Pearl
	{
	quest::summonitem("11696"); #Windstriker
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of the blade turn in
elsif(plugin::check_handin(\%itemcount, 20858 => 1, 20962 => 1, 20859 => 1, 20860 => 1)) #Efreeti Long Sword, Emerald Spiroc Feather, Bitter Honey, Circlet of Brambles
	{
	quest::summonitem("27732"); #Arydryidriyorn
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of thunder turn in
elsif(plugin::check_handin(\%itemcount, 20955 => 1, 20856 => 1, 20857 => 1)) #Djinni Statuette, Spiroc Thunder totem, White Gold Earring
	{
	quest::summonitem("14568"); #Thunderforged Earring
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71103 -- Gordon Treecaller