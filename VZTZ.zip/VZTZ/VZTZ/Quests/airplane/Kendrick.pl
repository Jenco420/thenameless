#Kendrick for rogue tests of Thievery, Silence, Trickery

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("$name, let us waste no more time! Do you wish to begin your test of [Thievery], [Silence], or [Trickery]?");
        }

#test of Thievery
if ($text =~/Thievery/i)
	{
        quest::say ("Thievery is absolute. Travel beyond and bring forth an Ivory Tessera, a gem of invigoration, and an enlaid choker to complete the test of thievery and earn the wispy choker of vigor!");
        }

#Test of Silence
elsif ($text =~/Silence/i)
	{
        quest::say ("Silence makes us deadly. Proceed upward and bring to me a spiroc sky totem, a pearlescent globe, and a black griffon feather. Griffon Wing Spauldors shall be yours if you complete this.");
        }

#Test of Trickery
elsif ($text =~/Trickery/i)
	{
        quest::say ("Trickery, ahh how Fizzlethorpe blesses us! Adventure and return a mottled spiroc feather, a cracked leather belt, and a sphinxian circlet to complete the test of trickery and earn Renards Belt of Quickness.");
        }
}

sub EVENT_ITEM
{
#test of Thievery turn in
if(plugin::check_handin(\%itemcount, 20928 => 1, 20984 => 1, 20985 => 1)) #Ivory Tessera, Gem of Invigoration, Inlaid Choker
	{
	quest::summonitem("14522"); #Wispy Choker of Vigor
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of Silence turn in
elsif(plugin::check_handin(\%itemcount, 20989 => 1, 20942 => 1, 20988 => 1)) #Spiroc Sky Totem, Pearlescent globe, black griffon feather
	{
	quest::summonitem("2703"); #Griffon Wing Spaulders
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Trickery turn in
elsif(plugin::check_handin(\%itemcount, 20956 => 1, 20992 => 1, 20993 => 1)) #Mottled Spiroc Feather, Cracked Leather Belt, Sphinxian Circlet
	{
	quest::summonitem("11676"); #Renard's Belt of Quickness
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71068 -- Kendrick