#lelulean for Enchanter test of Deception, Illusion, and metamorphism

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Great, let us waste no more time! I have three tests from which you can choose from. They are [Test of Illusion], [Test of Metamorphism], and [Test of Deception].");
        }

#Test of Deception
if ($text =~/deception/i)
	{
        quest::say ("Deception it is. Proceed upward through the sky and return to me a Rugous Globe, a Sky Pearl, and a Silken Mask. This will prove your abilities to me and I will reward you with an Ivory Mask.");
        }

#Test of Illusion
elsif ($text =~/illusion/i)
	{
        quest::say ("Illusion it is. Proceed upward through the sky and return to me a Crimson Tessera, a Darkstone Emerald, and a Finely Woven Cloth Cord. This will prove your abilities to me and I will reward you with a Cord of Sphinx Hair.");
        }

#Test of metamorphism
elsif ($text =~/metamorphism/i)
	{
        quest::say ("Metamorphism it is. Proceed upward through the sky and return to me a Silver Disk, a Bluish Stone, and a Light Cloth Mantle. This will prove your abilities to me and I will reward you with the Wind Walker's Mantle.");
        }
}

sub EVENT_ITEM
{
#test of deception turn in
if(plugin::check_handin(\%itemcount, 20945 => 1, 20772 => 1, 20771 => 1)) #Rugous Globe, Silken mask, Sky Pearl
	{
	quest::summonitem("1275"); #Ivory Mask
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#test of illusion turn in
elsif(plugin::check_handin(\%itemcount, 20931 => 1, 20767 => 1, 20768 => 1)) #Crimson Tessera, Darkstone Emerald Finely Woven Cloth Cord
	{
	quest::summonitem("1277"); #Sphinx Hair Cord
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of metamorphism turn in
elsif(plugin::check_handin(\%itemcount, 20938 => 1, 20769 => 1, 20770 => 1)) #Silver Disc, Bluish Stone, Light Cloth Mantle
	{
	quest::summonitem("1276"); #Wind Walker's Mantle
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71092 -- Lelulean