#Vanquisher #1 71009

sub EVENT_SPAWN
{
quest::signalwith("71116","99","1"); #signal to signal watcher 1 when killed
quest::signalwith("71008","99","1"); #signal to signal watcher 1 when killed
quest::signalwith("71007","99","1"); #signal to signal watcher 1 when killed
}
sub EVENT_DEATH
{
quest::signalwith("71116","5","1"); #signal to signal watcher 1 when killed
quest::signalwith("71008","1","1"); #signal to signal watcher 1 when killed
quest::signalwith("71007","1","1"); #signal to signal watcher 1 when killed
}