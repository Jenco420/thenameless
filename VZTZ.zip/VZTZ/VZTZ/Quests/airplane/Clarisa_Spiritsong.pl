#Clarisa Spiritsong for Bard test of Pitch, Bard test of Tone, Bard test of Voice

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Hi there $name! I give three sections of the test of songs, Denise does the rest. Do you wish to take the [Test of Pitch}, [Test of Voice], or [Test of Tone]?");
        }

#Bard test of Pitch
elsif ($text =~/pitch/i)
	{
        quest::say ("The pitch that we sing and play has a great affect on those that listen. Keep this in mind Gendal, and you shall always be welcome in taverns and inns. Now if you return to me Phosphoric Globe, a Shimmering Diamond, and crude wooden flute.");
        }

#Bard test of Tone
elsif ($text =~/tone/i)
	{
        quest::say ("Tone is important to all singers. Prove to me that you can keep your tone even and pure by bringing me an Ochre Tessera, a songbird statuette, and a light woolen mask. If you do this I will give you the mask of the songbird.");
        }

#Bard test of Voice
elsif ($text =~/voice/i)
	{
        quest::say ("The sweet sound rising forth from our throats are what makes us truly great. Go forth and give voice to your songs, and return to me a platinum disc, a music box, and a light woolen mantle. If you do this I shall give you the songweavers mantle. Good luck!");
        }
}

sub EVENT_ITEM
{
#bard test of pitch turn in
if(plugin::check_handin(\%itemcount, 20825 => 1, 20947 => 1, 20824 => 1)) #Crude Wooden Flute, Phosphoric Globe, Shimmering diamond
	{
	quest::summonitem("27722"); #Ervaj's Flute of Flight
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Bard test of tone turn in
elsif(plugin::check_handin(\%itemcount, 20933 => 1, 20620 => 1, 20821 => 1)) #Ochre Tessera, a songbird statuette, light woolen mask
	{
	quest::summonitem("27720"); #Mask of Song
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Bard test of voice turn in
elsif(plugin::check_handin(\%itemcount, 20823 => 1, 20822 => 1, 20940 => 1)) #Light Woolen manltle, Music box, Platinum Disc
	{
	quest::summonitem("27721"); #Mantle of the Songweaver
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71098 -- Clarisa Spiritsong