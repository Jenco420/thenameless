#Spawn 2 71111 - Bazzzazzt after killing 71115

sub EVENT_SPAWN {
	quest::settimer("depop",4800);
}





sub EVENT_DEATH {
	quest::spawn2(71111,0,0,$x,$y,$z,$h);
        quest::spawn2(71111,0,0,$x,$y,$z,$h);
}