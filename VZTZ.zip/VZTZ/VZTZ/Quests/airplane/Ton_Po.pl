#Ton_Po for Monk Tests of sight, speed, strength

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("So, I have been called upon to test you, and test you I shall. I will give you the option of choosing your test though enlightened one. Shall you take the test of [Strength], [Sight], or [Speed]?");
        }

#Test of Sight
if ($text =~/sight/i)
	{
        quest::say ("The test of sight is both a test of body and mind. The mind will allow you to see beyond that which is usually, invisible. Bring me a Gold Disc, a Tiny Ruby, and a Cracked Leather Eyepatch and I will assist you in seeing what should not be seen.");
        }

#Test of Speed
elsif ($text =~/Speed/i)
	{
        quest::say ("The test of speed. Every Monk must be swift if he is to best his opponent. Speed in both mind and body is essential in many facets of life. Return to me an Adumbrate Globe, a Shimmering Opal, and some Dove Slippers and I shall aid your speed of mind.");
        }

#Test of Strength
elsif ($text =~/strength/i)
	{
        quest::say ("So be it, the test of Strenth you shall have. Bring to me a Verdant Tessera, some Finely Woven Gold Mesh, and some Silken Strands. The task will not be easy, but it should serve as an adequate test of Strengh, for one of your abilities.");
        }
}

sub EVENT_ITEM
{
#Test of Sight turn in
if(plugin::check_handin(\%itemcount, 20939 => 1, 20795 => 1, 20796 => 1)) #Gold Disc, Tiny Ruby, Cracked Leather eyepatch
	{
	quest::summonitem("1280"); #Ton Po's Eyepatch
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of Speed turn in
elsif(plugin::check_handin(\%itemcount, 20946 => 1, 20797 => 1, 20798 => 1)) #Adumbrate Globe, Shimmering Opal, Dove Slippers
	{
	quest::summonitem("1280"); #Sandals of Alacrity
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Strength turn in
elsif(plugin::check_handin(\%itemcount, 20932 => 1, 20793 => 1, 20794 => 1)) #Verdant Tessera, Finely woven gold mesh, Silken strands
	{
	quest::summonitem("1282"); #Mystical Back Straps
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71096 -- Ton_Po