#Denise Songweaver for Bard test of harmony, Bard test of brass, Bard test of wind

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Hail and well met $name! I give the second half of the test of songs. If you are ready, choose between the [Test of Brass], [Test of Wind], or [Test of Harmony].");
        }

#Test of the harmony
elsif ($text =~/Harmony/i)
	{
        quest::say ("Working with the environment to enthrall those that listen to you is of the utmost importance to us. Go out and retrieve an efreeti war spear, some manna nectar, and a nebulous emerald and diamond. Return these items to me and receive the harmonic spear as your reward.");
        }

#Test of Brass
elsif ($text =~/Brass/i)
	{
        quest::say ("Then bring back to me an efreeti war horn, a saffron spiroc feather, adamintium bands, and a glowing diamond.");
        }

#Test of wind
elsif ($text =~/Wind/i)
	{
        quest::say ("Bring me an imp statuette, a dull stone, and an amulet of woven hair. Then I will give you the fae amulet.");
        }
}

sub EVENT_ITEM
{
#bard test of brass turn in
if(plugin::check_handin(\%itemcount, 20828 => 1, 20830 => 1, 20829 => 1, 20961 => 1)) #Adamantite bands, Efreeti War horn, Glowing Diamond, Saffron spiroc feather
	{
	quest::summonitem("27724"); #Dennon's horn of disaster
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#druid test of harmony turn in
elsif(plugin::check_handin(\%itemcount, 20831 => 1, 20968 => 1, 20833 => 1, 20832 => 1)) #Efreeti War Spear, Manna Nectar, Nebulous Diamond, Nebulous Emerald
	{
	quest::summonitem("10852"); #Harmonic Spear
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Druid test of wind turn in
elsif(plugin::check_handin(\%itemcount, 20827 => 1, 20826 => 1, 20953 => 1)) #Amulet of Woven Hair, Dull Stone, Imp Statuette
	{
	quest::summonitem("14565"); #Fae Amulet
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71099 -- Denise_Songweaver

#Bard test of brass
if ($text =~/brass/i)
	{
        quest::say ("So you wish the test of The Wolf do you? Go forth unto the islands and find an Azure Tessera, Black Face Paint and finally a Worn Leather Mask. Bring them back to me, but not until you have all three and you shall be rewarded.");
        }

#Bard test of wind
elsif ($text =~/wind/i)
	{
        quest::say ("Ah, the test of The Bear It Is. Find In this plane a Copper Disc, a Sky Emerald and a Mantle of Woven Grass. Bring all three at one time to me for your reward.");
        }

#Bard test of harmony
elsif ($text =~/harmony/i)
	{
        quest::say ("The test of The Tree is said to be a test of Nature and only those stout of limb and bark will succeed. Bring to me a Diaphanous Globe, some Hardened Clay and a Spiroc Battle Staff. Hand them all to me at once and the Reward will be yours");
        }
}

sub EVENT_ITEM
{
#bard test of brass turn in
if(plugin::check_handin(\%itemcount, 20930 => 1, 20728 => 1, 20729 => 1)) #azure tessera, black face paint, worn leather mask
	{
	quest::summonitem("2706"); #Drake-Hide Mask
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Bard test of wind turn in
elsif(plugin::check_handin(\%itemcount, 20953 => 1, 20826 => 1, 20827 => 1))
	{
	quest::summonitem("14565"); #Fae amulet
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Bard test of harmony turn in
elsif(plugin::check_handin(\%itemcount, 20831 => 1, 20968 => 1, 20832 => 1, 20833 => 1))
	{
	quest::summonitem("10852"); #harmonic spear
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71099 -- Will Treewalker

#----------------------------------------- old quest text
#Cilin_Spellsinger For Bard Tests - Loot Proof

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Bard')){  quest::say ("Greetings young Bard. Are you here [to be tested]?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Bard, begone!");
}
if ($text =~/to be tested/i) {  quest::say ("Then, tested you will be! There are many tests, choose one carefully: [Test of Harmony], [Test of Brass], [Test of Pitch], [Test of Tone], [Test of Voice] or [Test of Wind].");  }
if ($text =~/Test of Harmony/i) {  quest::say ("To complete the Test of Harmony, bring me the following treasures: the Efreeti War Spear from Noble Dojorn, Manna Nectar from a Bazzzazzt, a Nebulous Diamond from the Eye of Veeshan and a Nebulous Emerald from a Heartbane Drake.");  }

if ($text =~/Test of Brass/i) {  quest::say ("To complete the Test of Brass, bring me the following treasures: Adamantium Bands from a Bazzazzt, an Efreeti War Horn from the greater powers of this Plane, a Glowing Diamong from a Sister of the Spire and a Saffron Spiroc Feather from a Spiroc Guardian.");  }

if ($text =~/Test of Pitch/i) {  quest::say ("To complete the Test of Pitch, bring me the following treasures: a Crude Wooden Flute from the Spiroc Lord, a Phosphoric Globe from various entities in this Plane and a Shimmering Diamond from a Soul Harvester.");  }

if ($text =~/Test of Tone/i) {  quest::say ("To complete the Test of Tone, bring me the following treasures: an Ochre Tessera from a Thunder Spirit and a Songbird Statuette from the Protector of Sky.");  }

if ($text =~/Test of Voice/i) {  quest::say ("To complete the Test of Voice, bring me the following treasures: a Light Woolen Mantle from the Keeper of Souls, a Music Box from Gorgalosk or his minions and a Platinum Disc from an Azarack.");  }

if ($text =~/Test of Wind/i) {  quest::say ("To complete the Test of Wind, bring me the following treasures: an Amulet of Woven Hair from Bazzt Zzzt, a Dull Stone from Noble Dojorn and an Imp Statuette from various entities in this Plane.");  }
}

sub EVENT_ITEM
{
if (plugin::check_handin(\%itemcount, 20830 => 1, 20961 => 1, 20828 => 1, 20829 => 1))
{
quest::say("Well done, $name. Here is your reward.");
quest::summonitem("27724"); #Denon's Horn of Disaster
quest::exp(100000);
}

if(plugin::check_handin(\%itemcount, 20953 => 1, 20826 => 1, 20827 => 1)) {
quest::summonitem("14565"); #Fae amulet
quest::exp(100000);
quest::say("Well done, $name. Here is your reward.");
}
if(plugin::check_handin(\%itemcount, 20831 => 1, 20968 => 1, 20832 => 1, 20833 => 1)) {
quest::summonitem("10852"); #harmonic spear
quest::exp(100000);
quest::say("Well done, $name. Here is your reward.");
}
if(plugin::check_handin(\%itemcount, 20940 => 1, 20822 => 1, 20823 => 1)) {
quest::summonitem("27721"); #mantle of the songweaver
quest::exp(100000);
quest::say("Excellent! Take this as your reward.");
}
if(plugin::check_handin(\%itemcount, 20933 => 1, 20823 => 1, 20820 => 1)) {
quest::summonitem("27720"); #mask of song
quest::exp(100000);
quest::say("Excellent! Take this as your reward.");
}
if(plugin::check_handin(\%itemcount, 20947 => 1, 20824 => 1, 20825 => 1)) {
quest::summonitem("27722"); #Ervaj's flute of flight
quest::exp(100000);
quest::say("Excellent! Take this as your reward.");
}

plugin::return_items(\%itemcount);