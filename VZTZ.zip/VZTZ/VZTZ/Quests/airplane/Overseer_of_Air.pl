sub EVENT_SPAWN {
	$CazicTouchTimer = 0;
	my $LuckyGuy;
      quest::settimer("depop",4800);

}

sub EVENT_AGGRO {
	if ($CazicTouchTimer eq 0) {
		$CazicTouchTimer = 1;
		quest::settimer("1",45);
		quest::settimer("2",600);
		$LuckyGuy = ($npc->GetHateTop());
		$LuckyGuy = $LuckyGuy->GetID();
		quest::castspell(982,$LuckyGuy );
	}
}

sub EVENT_TIMER {
	if ($timer eq "1") {
		if ($CazicTouchTimer eq 1) {
			$LuckyGuy = ($npc->GetHateTop());
			$LuckyGuy = $LuckyGuy->GetID();
			quest::castspell(982,$LuckyGuy );
			quest::settimer("1",45);
		}
	}
	if ($timer eq "2") {
		quest::stoptimer("1");
		quest::stoptimer("2");
		$CazicTouchTimer = 0;
	}
      if ($timer eq "depop") {
		quest::depop();
	      quest::stoptimer("depop");
	}

}


sub EVENT_DEATH {
	quest::spawn2(71060,0,0,-1429,-269,1247,64);#spawn The Hand of Veeshan (on Island 8)
}