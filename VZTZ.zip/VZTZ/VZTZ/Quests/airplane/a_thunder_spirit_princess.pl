sub EVENT_SAY {
	if($text=~/hail/i) {
		quest::say("Greetings, travelers, welcome to the Plane of Sky! We are thunder spirits - this first island is our home. You are welcome to stay here as long as you like. If you wish to go to other islands you may purchase keys from the Key Master.");
	}
	if($text=~/gkzzallk/i) {
		quest::say("Gkzzallk lives far above here. We often take him tea because he's so nice to us fairies! He likes to chat with the others who live here and can often be found in the temple up above. If you give me a bit of money, I can go make sure he is home.");
	}
}

sub EVENT_ITEM {
	if($gold == 10) {
		quest::say("Thank you, $name. I will tell him to expect visitors.");
		quest::spawn2(71073,0,0,360.4,663.7,-54.7,109.3);
		quest::depop();
	}
}

sub EVENT_DEATH {
	quest::spawn2(71058,0,0,$x,$y,$z,$h);
}