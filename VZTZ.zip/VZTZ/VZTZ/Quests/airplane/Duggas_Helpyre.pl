#Duugas Helpyre for Necromancer tests of Heart, Finger, Hands

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("So, you dare be seen in my precense. Truly a brave fool you are. You come seeking fame and glory here do you? Well fool, perhaps you will get what you seek. Shall you take the test of the [Heart], the [Hands], or the [Finger]?");
        }

#Test of Heart
elsif ($text =~/Heart/i)
	{
        quest::say ("So the heart it be. Bring me, foolish one, an Imp Statuette, an Obsidian Amulet, and a Pulsating Ruby. Perhaps then, you shall find your reward.");
        }

#Test of Finger
elsif ($text =~/Finger/i)
	{
        quest::say ("The finger. Needed for nearly every casting you shall ever hope to produce, it truly is the most powerful creation. Should you bring me a White Spiroc Feather, a Nebulous Ring, and the Ring of Veeshan, I shall reward you with power that you can just now begin to comprehend.");
        }

#Test of Hands
elsif ($text =~/Hands/i)
	{
        quest::say ("The test of the Hands it shall be. Bring me a Gorgon's Head, some Aged Nectar, a Glowing Black Pearl, and an Efreeti's Great Staff. When you return, I shall reward you for your deeds, assuming you live through the experience. Hahaha!");
        }
}

sub EVENT_ITEM {

#Test of Heart turn in
if (plugin::check_handin(\%itemcount, 20953 => 1, 20786 => 1, 20787 => 1)) #Imp Statuette Obsidian Amulet, Pulsating Ruby
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("14560"); #Sphinx Heart Amulet
	quest::exp(100000);
	}

#Test of Finger turn in
elsif(plugin::check_handin(\%itemcount, 20960 => 1, 20788 => 1, 20789 => 1)) #White Spiroc Feather, Nebulous Ruby, Ring of Veehan
	{
	quest::summonitem("27713"); #Band of Wailing Winds
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Hands turn in
elsif(plugin::check_handin(\%itemcount, 20790 => 1, 20967 => 1, 20791 => 1, 20792 =>1)) #Gorgon Head, Aged Nectar, Glowing Black Pearl, Efreei Great Staff
	{
	quest::summonitem("11689"); #Gorgon Head Staff
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}


#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71094 -- Duugas Helpyre