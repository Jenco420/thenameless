#Inte Akera for Fiery Avenger

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Inte Akera says 'Greetings,$name. I am Inte Akera. I have retired to the Plane of Sky after a long [life toiling] on Norrath's soil. Have you retreated here as well, or are you merely visiting?'");
        }

#Paladin epic
if ($text =~/toil/i)
	{
        quest::say ("Inte Akera says 'Long ago, before I came to this plane, I fought in the name of Prexus against all the evils that plagued Norrath. In that time, I have done everything one can do. I have fought for the causes of good. I gained the esteem of kings and lords. The sword I hold is but one example of the treasures I have sought and won. I have accomplished all that I can, have all that I desire. My toil is done and now I sit among the clouds in peace, occasionally [blessing those who seek it] and are found worthy.");
        }

#Paladin Epic
elsif ($text =~/blessing/i)
	{
        quest::say ("Many come seeking my blessings. No matter how minor the blessing they ask, [all must prove] that they embody the qualities of a paladin before I bless them.'");
        }

#Paladin Epic
elsif ($text =~/prove/i)
	{
        quest::say ("I believe the two most important qualities of a paladin are [nobility and sacrifice]. Hand me an item of yours that proves you understand what nobility and sacrifice are. Be warned however, if I do not think as you do, I will simply accept the item as a gift, and give you no blessing.");
        }

#Paladin Epic
elsif ($text =~/nobility/i)
	{
        quest::say ("No.. I was unable to kill my most hated foe, [Miragul]. The head of this wretched, foul necromancer is forever out of the reach of justice. It would be worth restoring him to his former state for the chance to take his head as a trophy.");
        }

#Paladin Epic
elsif ($text =~/Miragul/i)
	{
        quest::say ("You think you can succeed where I cannot? Perhaps you can noble one.. Bring me the head of Miragul, his robe and hand me back the two blessings I gave you, and in return I shall bequeath to you this sword I carry. Good luck my friend.");
        }
}

sub EVENT_ITEM
{

#test of spirit turn in
if(plugin::check_handin(\%itemcount, 5504 => 1)) #soulfire
	{
	quest::summonitem("18033"); #Inte's First Blessing
	quest::exp(100000);
	quest::say("You have chosen wisely, my friend. Take this note as a token of my blessing upon you.");
        quest::faction(79,250); #deep water knights
        quest::faction(145,100); #High Council of Euridin
        quest::faction(143,-100); #heretics
	}
if(plugin::check_handin(\%itemcount, 5403 => 1)) #Ghoulbane
	{
	quest::summonitem("18034"); #Inte's Second Blessing
	quest::exp(100000);
	quest::say("You have chosen wisely, my friend. Take this note as a token of my blessing upon you.");
        quest::faction(79,250); #deep water knights
        quest::faction(145,100); #High Council of Euridin
        quest::faction(143,-100); #heretics
	}
if(plugin::check_handin(\%itemcount, 19073 => 1, 1254 => 1, 18033 => 1, 18034 =>1)) #Miragul's Head, Miragul's Robe, Inte's First Blessing, Inte's Second Blessing
	{
	quest::summonitem("11050"); #Fiery Avenger
	quest::exp(100000);
	quest::say("Long have I awaited this moment. You have done what even I thought impossible. Take this sword, the Fiery Avenger. You have earned both it and my deepest respect.");
	quest::faction(79,250); #deep water knights
        quest::faction(145,100); #High Council of Euridin
        quest::faction(143,-100); #heretics
        }
#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71107 -- Dirkog_Steelhand