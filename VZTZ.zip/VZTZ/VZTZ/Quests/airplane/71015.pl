#Spiroc Caller

sub EVENT_SPAWN
{
$Caller = 1;
}

sub EVENT_SIGNAL {

if($signal eq 1)
	{
	$Caller -= 1;
	}
	
if($signal eq 99)  
		{
	if ($Caller < 1) {
		$Caller += 1;
		}
	}
	
}

sub EVENT_DEATH
{
if ($Caller == 1)
	{
        quest::spawn2(71015,18,0,1097.50,-522.24,484.76,$h); #spawn Caller if Vanquisher is still up
        }
}
