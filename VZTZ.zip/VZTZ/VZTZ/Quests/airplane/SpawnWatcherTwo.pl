sub EVENT_SIGNAL {
	if($signal eq 2){
		quest::settimer("Island2", 45);
	}
}

sub EVENT_TIMER {
	if($timer eq "Island2") {
		quest::spawn2(71059,0,0,-570,-140,-314,128);
		quest::stoptimer("Island2");
	}
}