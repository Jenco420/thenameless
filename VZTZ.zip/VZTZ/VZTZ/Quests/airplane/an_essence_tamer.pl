#Spawn Essence Tamer after killing essence carrier
sub EVENT_SPAWN {
quest::settimer("depop3",4800);
}

sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop3");
        }
        
