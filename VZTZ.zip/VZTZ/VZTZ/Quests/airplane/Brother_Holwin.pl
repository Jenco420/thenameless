#Brother Holwin for Monk Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Monk')){  quest::say ("Peace to you, $name.  I see that you have come far along the path of tranquility and enlightenment.  Do you wish to [test yourself] further, and perhaps complete the path you started on so long ago?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Monk, begone!");
}
if ($text =~/test/i && ($class eq 'Monk')){  quest::say ("Choose you path. [Wu the Enlightened] or [Ton Po]");  }

	#summon Wu the Enlightened
	if(($text=~/Wu/i) && ($class eq "Monk")) {quest::say("I shall summon them for you");
	quest::spawn2(71097,0,0,660.0,1332.3,-766.9,189.9);
	quest::depop();
	}

	#summon Ton Po
	if(($text=~/Ton/i) && ($class eq "Monk")){quest::say("I shall summon them for you");
	quest::spawn2(71096,0,0,660.0,1315.0,-766.9,189.9);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71046 -- Brother Holwin