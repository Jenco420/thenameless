#Dason_Goldblade For Paladin Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Paladin'))
{
    quest::say ("Greetings, $name.  Are you pure of [heart and soul]?");
}
elsif($text=~/Hail/i)
{
    quest::say ("You are not a Paladin, begone!");
}
if ($text =~/heart and soul/i && ($class eq 'Paladin'))
	{
        quest::say ("Then choose. Do you wish your purity to be tested by [Gregori Lightbringer] or [Dirkog Steelhand]?");
        }

	#talk to Dirkog Steelhand
	elsif(($text=~/Dirkog/i) && ($class eq "Paladin"))
        {
        quest::say("Dirkog is a gruff one, but his faith is what all paladins should strive to equal. Read this book and return it to me. After you have done so, I shall summon Dirkog to test you.");
        quest::summonitem("18527"); #Walk with Evil
        }

	#summon Gregori Lightbringer
	elsif(($text=~/Gregori/i) && ($class eq "Paladin"))
        {
        quest::say("I shall summon them for you");
	quest::spawn2(71106,0,0,563,1331.1,-766.9,63.4);
	quest::depop();
	}
}

sub EVENT_ITEM
{
#accept walk with evil book & summon Dirkog
if(plugin::check_handin(\%itemcount, 18527 => 1)) #Walk with Evil
	{
        quest::say("I shall summon them for you");
	quest::spawn2(71107,0,0,563,1331.1,-766.9,63.4);
	quest::depop();
	}
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}
#END of FILE Zone:airplane  ID:71084 -- Dason Goldblade