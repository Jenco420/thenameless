#Tynicon D'Lin for shadowknight test of Disempowerment, Envenoming, necropotence, Raising the Dead

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Great, let us waste no more time! I offer to you four challenges. [Disempowement], [Envenoming],  [Raising of the Dead], or [Necropotence]. Choose one to be tested on.");
        }
        
#test of Disempowerment
if ($text =~/Disempowerment/i)
	{
        quest::say ("Disempowerment, destroying goodly magic. Proceed upward through the sky and return to me a Griffon Statuette, a Blood Sky Emerald, and Rusted Pauldrons. This will prove your abilities to me and I will reward you with Blood Sky Faceplate.");
        }

#Test of Envenoming
elsif ($text =~/Envenoming/i)
	{
        quest::say ("Only the most powerful and vile of shadow knights manage to complete this test. Return to me an Efreeti War Axe, some Dulcet Nectar, a Bloodstained Hilt, and a Blood Sky Ruby. Doing so will earn you the right to wield the Drinker of Blood.");
        }

#Test of Necropotence
elsif ($text =~/Necropotence/i)
	{
        quest::say ("Only the most powerful and vile of shadow knights manage to complete this test. Return to me an Efreeti War Axe, some Dulcet Nectar, a Bloodstained Hilt, and a Blood Sky Ruby. Doing so will earn you the right to wield the Drinker of Blood.");
        }

#Test of raising the dead
elsif ($text =~/raising the dead/i)
	{
        quest::say ("he dead are our allies against those that would oppose us. Proceed upward through the sky and return to me a Large Sky Pearl, a Jar of Honey, a Sphinxian Ring, and Fae Pauldrons. This will prove your abilities to me and I will reward you with an Pearlescent Pauldrons.");
        }
}

sub EVENT_ITEM
{
#test of Disempowerment turn in
if(plugin::check_handin(\%itemcount, 20950 => 1, 20703 => 1, 20704 => 1)) #Griffon Statuette, Blood Sky Emerald, Rusted Paudrons
	{
	quest::summonitem("4322"); #Blood Sky Face Plate
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of Envenoming turn in
elsif(plugin::check_handin(\%itemcount, 20705 => 1, 20957 => 1, 20706 => 1)) #Efreeti War Shield, Dark Spiroc Feater, Obsidian Shard
	{
	quest::summonitem("11678"); #Obtenebrate Mithril Guard
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Necropotence turn in
elsif(plugin::check_handin(\%itemcount, 20771 => 1, 20964 => 1, 20712 => 1, 20713 =>1)) #Efreeti War Axe, Dulcet Nectar, Booldstained Hilt, Blood sky ruby
	{
	quest::summonitem("11678"); #Rheumguls
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of raising the dead turn in
elsif(plugin::check_handin(\%itemcount, 20707 => 1, 20708 => 1, 20709 => 1, 20710 =>1)) #Large Sky Pearl, Jar of Honey, Sphinxian Ring, Rae Pauldrons
	{
	quest::summonitem("27704"); #Need Pearlescent Pauldrons added to the database
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}
#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71105 -- Tynicon D'Lin