#Ranger Spirit for Ranger Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Ranger')){  quest::say ("Greetings, $name. Are you a true [servant of the Pine?]");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Ranger, begone!");
}
if ($text =~/pine/i && ($class eq 'Magician')){  quest::say ("Very well my friend. In order to reach your true potential you must pass many tests. [Relinin Skyrunner] and [Gordon Treecaller] are here to perform these tests. Please choose one.");  }

	#summon Relinin Skyrunner
	if(($text=~/Relinin/i) && ($class eq "Ranger")) {quest::say("I shall summon them for you");
	quest::spawn2(71102,0,0,617.1,1399.5,-766.9,129.4);
	quest::depop();
	}

	#summon Gordon Treecaller
	if(($text=~/Gordon/i) && ($class eq "Ranger")){quest::say("I shall summon them for you");
	quest::spawn2(71103,0,0,592.8,1400.1,-766.9,129.4);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71054 -- Ranger Spirit