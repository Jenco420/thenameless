#Alan Harten Cleric test of Courage, Protection, and Skill

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Greetings faithful. Your faith shall be tested this day.  Shall you take the [test of courage], [test of skill], or [test of protection?]");
        }

#Test of courage
elsif ($text =~/courage/i)
	{
        quest::say ("You have come seeking the knowledge and treasures that I posses. I will impart such things to you, if you do a service to your god. It matters not who that god may be, but the service and the faith you must exemplify. Bring to me an Ochre Tessera, a Sky Emerald, and a Silver Hoop.");
        }

#Test of skill
elsif ($text =~/skill/i)
	{
        quest::say ("The test of skill it will be. Bring to me, a Golden Disc, a Dark Wood, and a Small Shield. You shall be rewarded upon your return.");
        }

#Test of protection
elsif ($text =~/protection/i)
	{
        quest::say ("So, you must be a great protector to have ventured this far. Bring for me an Adumbrate Globe, a Glowing Diamond, and some Shiny Pauldrons for your reward.");
        }
}

sub EVENT_ITEM {

#Cleric test of courage turn in
if (plugin::check_handin(\%itemcount, 20933 => 1, 20807 => 1, 20806 => 1)) #ochre Tessera, silver hoop, sky emerald
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("14563"); #Truewind Earring
	quest::exp(100000);
	}

#cleric test of protection turn in
elsif(plugin::check_handin(\%itemcount, 20946 => 1, 20829 => 1, 20811 => 1)) #Adumbrate Globe, Glowing Diamond, Shiny Pauldrons
	{
	quest::summonitem("27717"); #Pauldrons of Piety
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Cleric test of Skill turn in
elsif(plugin::check_handin(\%itemcount, 20808 => 1, 20939 => 1, 20809 => 1)) #Dark Wood, Gold Disc, Small Shield
	{
	quest::summonitem("27716"); #Aegis of the Wind
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71087 -- Alan Harten