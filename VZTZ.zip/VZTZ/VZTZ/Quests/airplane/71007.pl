#spiroc banisher
sub EVENT_SPAWN
{
$Banisher = 1;
}

sub EVENT_SIGNAL {

if($signal eq 1) 
	{
	$Banisher -= 1;
	}
	
if($signal eq 99) 
		{
	if ($Banisher < 1) {
		$Banisher += 1;
		}
	}
	
}

sub EVENT_DEATH
{
if ($Banisher == 1)
	{
        quest::spawn2(71007,23,0,1119.04,-776.41,444.72,$h); #spawn banisher again if vanquisher is not dead
        }
}

