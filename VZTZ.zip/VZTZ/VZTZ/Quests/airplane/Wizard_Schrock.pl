#Wizard Schrock for Wizard Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Wizard')){  quest::say ("Greetings, $name.  Do you believe that you are a [great wizard]?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Wizard, begone!");
}
if ($text =~/wizard/i && ($class eq 'Wizard')){  quest::say ("I will not take your word for it!  You must prove your greatness to my apprentices.  Do you wish to be tested by [Neasin Leornic] or by [Abec Ianor]?");  }

	#Neasin Leornic
	if(($text=~/Neasin/i) && ($class eq "Wizard")) {quest::say("I shall summon them for you");
	quest::spawn2(71088,0,0,585,1304.3,-766.9,0.1);
	quest::depop();
	}

	#Summon Abec Ianor
	if(($text=~/Abec/i) && ($class eq "Wizard")){quest::say("I shall summon them for you");
	quest::spawn2(71089,0,0,585,1304.3,-766.9,0.1);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71047 -- Wizard Schrock