#Spawn Bazzt_Zzzt after killing Bzzzt

sub EVENT_SPAWN {
	quest::settimer("depop",4800);
}





sub EVENT_DEATH {
	quest::spawn2(71079,0,0,$x,$y,$z,$h);
}