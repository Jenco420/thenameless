#Strandar_Pinemist For Druid Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Druid')){  quest::say ("Greetings young Druid. Are you here [to be tested]?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Druid, begone!");
}
if ($text =~/to be tested/i && ($class eq 'Druid')){  quest::say ("Who do you wish to be tested by young Druid, [Will Treewalker] or [Fenalla Moonshadow]?");  }

	#summon Will Treewalker
	if(($text=~/Will/i) && ($class eq "Druid")) {quest::say("I will summon him for you then");
	quest::spawn2(71086,0,0,563,1311.4,-766.9,65.4);
	quest::depop();
	}

	#summon Fenalla Moonshadow
	if(($text=~/Fenalla/i) && ($class eq "Druid")){quest::say("I will summon her for you then");
	quest::spawn2(71085,0,0,562.5,1329.3,-766.9,65.4);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:4825 -- Strandar_Pinemist