sub EVENT_SPAWN {
	quest::signalwith(9948234,1);
	quest::settimer("pingalive1", 15);
}

sub EVENT_TIMER {
	if($timer eq "pingalive1") {
		quest::signalwith(9948234,1);
		quest::settimer("pingalive1", 15);
	}
}