sub EVENT_DEATH {
	quest::spawn2(71058,0,0,$x,$y,$z,$h);
}