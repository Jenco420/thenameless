#Enderbite for Enchanter tests of Disilusion, Incapacitation, memorization

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Great, let us waste no more time! I have three tests from which you can choose from. They are [Test of Disillusion], [Test of Memorization], and [Test of Incapacitation].");
        }

#test of Disillusion
if ($text =~/disillusion/i)
	{
        quest::say ("Disillusion it is. Proceed upward through the sky and return to me a Harpy Statuette, a Nebulous Sapphire, and an Adamintium Earring. This will prove your abilities to me and I will reward you with an Earring of Displacement..");
        }

#Test of Incapacitation
elsif ($text =~/incapacitation/i)
	{
        quest::say ("Incapacitation it is. Proceed upward through the sky and return to me an Efreeti Wind Staff, some Sweet Nectar, a Black Sky Diamond, and a Large Sky Sapphire. This will prove your abilities to me and I will reward you with the Staff of Warding Winds.");
        }

#Test of Memorization
elsif ($text =~/memorization/i)
	{
        quest::say ("Memorization it is. Proceed upward through the sky and return to me a Carmine Spiroc Feather, a Ganoric Poison, and a Glowing Necklace. This will prove your abilities to me and I will reward you with a Necklace of Whispering Winds.");
        }
}

sub EVENT_ITEM
{
#test of Disillusion turn in
if(plugin::check_handin(\%itemcount, 20774 => 1, 20952 => 1, 20802 => 1)) #Adamantium Earring, Harpy Statuette, Nebulous Sapphire
	{
	quest::summonitem("14559"); #Earring of Displacement
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of incapacitation turn in
elsif(plugin::check_handin(\%itemcount, 20777 => 1, 20779 => 1, 20778 => 1, 20968 => 1)) #Black sky diamond, Efreeti wind staff, Large sky sapphire, sweet nectar
	{
	quest::summonitem("27711"); #Rod of the protecting Winds
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of memorization turn in
elsif(plugin::check_handin(\%itemcount, 20823 => 1, 20822 => 1, 20940 => 1)) #Light Woolen manltle, Music box, Platinum Disc
	{
	quest::summonitem("27721"); #Mantle of the Songweaver
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71093 -- Enderbite