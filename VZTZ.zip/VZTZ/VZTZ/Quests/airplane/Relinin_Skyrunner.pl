#Relinin Skyrunner for Ranger tests of Defense, Earth, Body

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Greetings $name. I can only assume my reasons for being summoned is that you wish to take the tests. Would you like to be tested in the [body], in [defense], or in the element of [earth?]");
        }

#Test of Defense
if ($text =~/Defense/i)
	{
        quest::say ("Defense it is. You must prove yourself worthy enough for the Spiroc spirits to guard you. Bring back to me a mithril disc, a harpy tongue, and a fine velvet cloak. Good luck to you.");
        }

#Test of Earth
elsif ($text =~/earth/i)
	{
        quest::say ("Elemental earth you say? When honed, the elements can be among our best allies. Retrieve a gridelin globe, a dragon hide mantle, and a spiroc earth totem. Only with these items can you master the element of earth.");
        }

#Test of Body
elsif ($text =~/body/i)
	{
        quest::say ("Very well. You must scour this plane and bring back to me these components: an auburn tessera, a ysgaril root, and a griffon talon. Make haste, and good luck.");
        }
}

sub EVENT_ITEM
{
#Test of Defense turn in
if(plugin::check_handin(\%itemcount, 20851 => 1, 50852 => 1, 20853 => 1)) #Mithril Disc, harpy Tongue, Fine Velvet Cloak
	{
	quest::summonitem("27731"); #Dark Cloak of the Sky
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of Earth turn in
elsif(plugin::check_handin(\%itemcount, 20948 => 1, 20854 => 1, 20855 => 1)) #Gridelin Globe, Dragon-hide mantle, Spiroc Earth Totem
	{
	quest::summonitem("2714"); #Earthshaker's Mantle
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Body turn in
elsif(plugin::check_handin(\%itemcount, 20934 => 1, 20849 => 1, 20850 => 1)) #Auburn Tessera, Ysgaril Root, Griffon Talon
	{
	quest::summonitem("14567"); #Griffon Talon Necklace
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71102 -- Relinin Skyrunner