#Abec_Ianor for Wizard tests of Conception, Visualizaion, Preparation

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Great, let us waste no more time! Do you wish to begin your test of [conception], [visualization], or [preparation]?");
        }

#Test of Conception
elsif ($text =~/Conception/i)
	{
        quest::say ("Conception is vital. Travel beyond and bring forth an Efreeti Statuette, a Mithril Air Ring, and a Box of Winds. From these I will produce a ring that will protect you where ever you go.");
        }

#Test of Visualiaation
elsif ($text =~/visualization/i)
	{
        quest::say ("Visualize and succeed. Proceed upward and bring to me a White-Tipped Spiroc Feather, a Pulsating Sapphire, and an Amethyst Amulet. With these items, I will be able to produce an amulet that will aid in your travels to our home.");
        }

#Test of Preparation
elsif ($text =~/preparation/i)
	{
        quest::say ("Always be prepared. Adventure and return an Efreeti War Staff, some Lush Nectar, a Copper Air Band, and a large Sky Sapphire. And you shall be rewarded with the Staff of Storms.");
        }
}

sub EVENT_ITEM {

#Test of Conception turn in
if (plugin::check_handin(\%itemcount, 20951 => 1, 20747 => 1, 20748 => 1)) #Efreeti Statuette, Mithril Air Ring, Box of Winds
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("11686"); #Solidate Mithril Ring
	quest::exp(100000);
	}

#Test of Visualiaation turn in
elsif(plugin::check_handin(\%itemcount, 20958 => 1, 20749 => 1, 20750 => 1)) #White Tipped Spiroc Feather, Pulsating Sapphire, Amethyst Amulet
	{
	quest::summonitem("14556"); #Amulet of Planar Transference
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Preparation turn in
elsif(plugin::check_handin(\%itemcount, 20753 => 1, 20965 => 1, 20751 => 1, 20778 =>1)) #Efreeti War Staff, Lush nectar, Copper Air Band, Large Sky Sapphire
	{
	quest::summonitem("11685"); #Nargon's Staff
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}


#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71089 -- Abec Ianor