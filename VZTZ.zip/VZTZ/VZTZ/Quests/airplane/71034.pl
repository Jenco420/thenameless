sub EVENT_SPAWN {
$CazicTouchTimer = 0;
my $LuckyGuy;
}



sub EVENT_AGGRO {
if ($CazicTouchTimer eq 0) {
	$CazicTouchTimer = 1;
	quest::settimer("1",45);
	$LuckyGuy = ($npc->GetHateTop());
	$LuckyGuy = $LuckyGuy->GetID();
	quest::castspell(982,$LuckyGuy );
}
}


sub EVENT_TIMER {

if ($timer eq "1") {
if ($CazicTouchTimer eq 1) {
	$LuckyGuy = ($npc->GetHateTop());
	$CazicTouchTimer = 1;
	$LuckyGuy = $LuckyGuy->GetID();
	quest::castspell(982,$LuckyGuy );
	}
$CazicTouchTimer = 0;
}
#if ($timer eq "2") {
#	quest::shout("I'm gunna slay you again");
#	quest::settimer("1", 45);
#	$CazicTouchTimer = 0;
#	quest::stoptimer("2");
#}



}
sub EVENT_DEATH
{
quest::stoptimer("1");
quest::spawn2(71060,0,0,-1429,-269,1247,64); #spawn The Hand of Veeshan (on Island 8)
}
