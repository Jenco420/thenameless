sub EVENT_SPAWN
{
$respawn = 1;
}

sub EVENT_SIGNAL {

if($signal eq 1) 
	{
	$respawn -= 1;
	}
	
if($signal eq 99) 
		{
	if ($respawn < 1) {
		$respawn += 1;
		}
	}
	
}

sub EVENT_DEATH
{
if ($respawn == 1)
	{
        quest::spawn2(71012,0,0,761.84,-241.35,409.79,$h); #spawn Spiroc Lord again if Guardian is alive)
        }
quest::spawn2(71075,0,0,$x,$y,$z,$h); #spawn Sirran the Lunatic (Island #5 version)
}

