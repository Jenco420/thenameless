#Spawn 71083 - Bzzzt after killing 71110


sub EVENT_SPAWN {
	quest::settimer("depop",4800);
}



sub EVENT_DEATH {
	quest::spawn2(71083,0,0,$x,$y,$z,$h);
}