#Spawn Essence carrier x2 after killing essence harvester
my $mob1;
my $mob2;
my $mobnpc1;
my $mobnpc2;
my $entid1;
my $entid2;

sub EVENT_DEATH
{
$entid1 = quest::spawn2(71070,0,0,($x-5),$y,$z,$h);
$entid2 = quest::spawn2(71070,0,0,($x+5),$y,$z,$h);
quest::signalwith("71116","3","1");
$mob1 = $entity_list->GetMobID($entid1);
$mob2 = $entity_list->GetMobID($entid2);
$mobnpc1 = $mob1->CastToNPC();
$mobnpc2 = $mob2->CastToNPC();
$mobnpc1->AddToHateList($npc->GetHateTop());
$mobnpc2->AddToHateList($npc->GetHateTop());

}