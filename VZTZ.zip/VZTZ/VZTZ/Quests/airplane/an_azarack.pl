sub EVENT_SPAWN
{
quest::signalwith(9948240,2);
#quest::shout("Debug:: Signal2 Sent to 9948234.");
quest::settimer("pingalive2", 15);
#quest::shout("Debug:: Timer:: pingalive2 set to 15 seconds");
quest::signalwith("71116","99","1");
}

sub EVENT_TIMER
{
	if($timer eq "pingalive2")
	{
#	quest::shout("Debug:: pingalive2 timer triggered");
	quest::signalwith(9948240,2);
#	quest::shout("Debug:: Signal2 Sent to 9948234");
	quest::settimer("pingalive2", 15);
#	quest::shout("Debug:: Timer:: pingalive2 set to 15 seconds");
	}
}

sub EVENT_DEATH
{
quest::signalwith("71116","4","1");
}

