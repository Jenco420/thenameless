#spiroc expulser

sub EVENT_SPAWN
{
$Expulser = 1;
}

sub EVENT_SIGNAL {

if($signal eq 1) 
	{
	$Expulser -= 1;
	}
	
if($signal eq 99) 
		{
	if ($Expulser < 1) {
		$Expulser += 1;
		}
	}
	
}

sub EVENT_DEATH
{
if ($Expulser == 1)
	{
        quest::spawn2(71011,20,0,703.42,-514.32,446.27,$h); #spawn spiroc expulser if vanquisher is up
        }
}

