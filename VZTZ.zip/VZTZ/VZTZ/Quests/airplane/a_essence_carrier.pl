#Spawn Essence Tamer after killing essence carrier

sub EVENT_SPAWN {
#quest::targlobal("Ekim","1","F",$mobid,$user,$zoneid);
}

sub EVENT_DEATH {
  quest::spawn2(71071,0,0,$x,$y,$z,$h);
}