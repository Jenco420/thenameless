sub EVENT_SPAWN
{
$respawn = 1;
$CazicTouchTimer = 0;
my $LuckyGuy;
}

sub EVENT_AGGRO {
   if ($CazicTouchTimer eq 0) {
	$CazicTouchTimer = 1;
	quest::settimer("1",45);
        quest::settimer("2",1800);
        $LuckyGuy = ($npc->GetHateTop());
	$LuckyGuy = $LuckyGuy->GetID();
	quest::castspell(982,$LuckyGuy );
   }
  }

sub EVENT_SIGNAL {

if($signal eq 1) 
	{
	$respawn -= 1;
	}
	
if($signal eq 99) 
		{
	if ($respawn < 1) {
		$respawn += 1;
		}
	}
	
}

sub EVENT_TIMER {

   if ($timer eq "1") {
     if ($CazicTouchTimer eq 1) {
	$LuckyGuy = ($npc->GetHateTop());
	$LuckyGuy = $LuckyGuy->GetID();
	quest::castspell(982,$LuckyGuy );
        quest::settimer("1",45);
     }
   }
   if ($timer eq "2") {
        quest::stoptimer("1");
        quest::stoptimer("2");
	$CazicTouchTimer = 0;
   }
  }


sub EVENT_DEATH
{
quest::stoptimer("1");
if ($respawn == 1)
	{
        quest::spawn2(71012,0,0,761.84,-241.35,409.79,$h); #spawn Spiroc Lord again if Guardian is alive)
        }
else
{
quest::spawn2(71058,0,0,$x,$y,$z,$h); #spawn Sirran the Lunatic (Island #5 version)
}
}
