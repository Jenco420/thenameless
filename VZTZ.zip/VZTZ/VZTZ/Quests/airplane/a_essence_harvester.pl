#Spawn Essence carrier x2 after killing essence harvester
sub EVENT_DEATH
{
quest::spawn2(71070,0,0,$x,$y,$z,$h);
quest::spawn2(71070,0,0,$x,$y,$z,$h);
#quest::signalwith(71116, 3, 0);
#quest::shout("FUCKING FUCK FUCK FUCKING DUCK");

}