#Farlorn for warrior test of skill, strength, force

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Do not waste my time, $name.  Do you wish to take the [test of blades] or not?");
        }


#Test of blades (starts skill, strenght, force, smash)
elsif ($text =~/blades/i)
	{
        quest::say ("The test of blades is not easy.  I hope you are as powerful as you are brave.  What do you wish to strive for? [Strength], [smash], [force], or [skill]?");
        }

#Test of Skill
elsif ($text =~/skill/i)
	{
        quest::say ("The test of skill it is. Go upward and retrieve these three items: an ivory tessera, a small ruby, and an azure ring. Return these to me and the azure ruby ring shall be yours.");
        }

#Test of Strength
elsif ($text =~/strength/i)
	{
        quest::say ("remember, true strength lies not only in the body, but in the mind as well. Return to me a bronze disc, a small pick and a stone amulet. If you manage to do this my runed wind amulet will be yours.");
        }

#Test of force
elsif ($text =~/force/i)
	{
        quest::say ("Foolishness or bravery Gendal? We shall see. Return to me a pearlescent globe, a silver mesh and a spiroc air totem. In return, you will receive both my deepest respect and the aerated pauldrons.");
        }
}

sub EVENT_ITEM {

#Test of Skill turn in
if (plugin::check_handin(\%itemcount, 20928 => 1, 20970 => 1, 20971 => 1)) #Ivory Tessera, Small Ruby, Azure Ring
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("14551"); #Azure Ruby Ring
	quest::exp(100000);
	}

#Test of Strength turn in
elsif(plugin::check_handin(\%itemcount, 20935 => 1, 20972 => 1, 20973 => 1)) #Bronze Disc, Small Pick, Stone Amulet
	{
	quest::summonitem("14569"); #Runed Wind Amulet
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of force turn in
if(plugin::check_handin(\%itemcount, 20942 => 1, 20974 => 1, 20975 => 1)) #Pearlescent Globe, Silver Mesh, Spiroc Air Totem
	{
	quest::summonitem("4321"); #Aerated Pauldrons
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71104 -- Farlorn