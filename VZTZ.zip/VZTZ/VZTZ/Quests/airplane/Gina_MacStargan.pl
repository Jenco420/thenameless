#Gina MacStargan for Shaman tests of might, health, sight

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Greetings, $name. I will test you in the tests of [might], [health], and [sight]. Which will it be?");
        }


#Test of Might
elsif ($text =~/Might/i)
	{
        quest::say ("The test of might It Is. Go find an Auburn Tessera, a Drake Fang and a Leather Chord. Bring them to me when you have them all and I shall reward you.");
        }

#Test of Health
elsif ($text =~/Health/i)
	{
        quest::say ("The test of health Is difficult. I am sure that you will find It a challenge. Bring to me a Platinum Disc, some Ethereal Amber, a Shimmering Amber and finally a Ceremonial Belt. Return them all to me at once and you shall have your just reward.");
        }

#Test of Sight
elsif ($text =~/Sight/i)
	{
        quest::say ("So you wish to take the test of sight do you? Get me a Phosphoric Globe, a Sphinx Hide and a Light Damask Mantle. Give them all to me at the same time and I shall reward you well.");
        }
}

sub EVENT_ITEM {
#Test of Might turn in
if (plugin::check_handin(\%itemcount, 20934 => 1, 20834 => 1, 20835 => 1)) #Auburn Tessera, Drake Fang, Leather Cord
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("27728"); #Amulet of the Fang
	quest::exp(100000);
	}

#Test of Health turn in
elsif(plugin::check_handin(\%itemcount, 20940 => 1, 20836 => 1, 20837 => 1, 20838 => 1))  #Platinum Disc, Ethereal Amber, Shimmering Amber, Ceremonial Belt
	{
	quest::summonitem("27727"); #Bracelet of the Spirits
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Sight turn in
elsif(plugin::check_handin(\%itemcount, 20947 => 1, 20839 => 1, 20840 => 1))  #Phosphoric Globe, sphinx hide, light damask mantle
	{
	quest::summonitem("27728"); #Fairy Hide Mantle
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71044 -- Gina MacStargan