sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("Hello there, brave traveller. I sell keys that take you to other islands in this here Plane of Sky. My prices are the best around. Heh, heh."); 
	}
}
#END of FILE Zone:airplane  ID:2977 -- Key_Master 