#Clarisa Spellsong for Bard test of Pitch, Bard test of Tone, Bard test of Voice

sub EVENT_SPAWN {
	quest::settimer("depop",300);
}

sub EVENT_SAY {
	if ($class eq 'Bard') { 
		if ($text =~/Hail/i) {  
			quest::say ("Greetings young Bard. Are you here [to be tested]?");  
		}
		if ($text =~/to be tested/i) {  
			quest::say ("Then, tested you will be! There are many tests, choose one carefully: [Test of Harmony], [Test of Brass], [Test of Pitch], [Test of Tone], [Test of Voice] or [Test of Wind].");  
		}
		if ($text =~/harmony/i) {  
			quest::say ("To complete the Test of Harmony, bring me the following treasures: the Efreeti War Spear from Noble Dojorn, Manna Nectar from a Bazzzazzt, a Nebulous Diamond from the Eye of Veeshan and a Nebulous Emerald from a Heartbane Drake.");  
		}
		if ($text =~/brass/i) {  
			quest::say ("To complete the Test of Brass, bring me the following treasures: Adamantium Bands from a Bazzazzt, an Efreeti War Horn from the greater powers of this Plane, a Glowing Diamong from a Sister of the Spire and a Saffron Spiroc Feather from a Spiroc Guardian."); 
		}
		if ($text =~/wind/i) {  
			quest::say ("To complete the Test of Wind, bring me the following treasures: an Amulet of Woven Hair from Bazzt Zzzt, a Dull Stone from Noble Dojorn and an Imp Statuette from various entities in this Plane.");  
		}
	} else {
		if($text=~/Hail/i){  
			quest::say ("You are not a Bard, begone!");
		}
	}
}

sub EVENT_ITEM {
	#Efreeti War Horn, Saffron Spiroc Feather, Adamantium Bands, Glowing Diamond
	if (($itemcount{20830} == 1) && ($itemcount{20961} == 1) && ($itemcount{20828} == 1) && ($itemcount{20829} == 1)) {
		quest::say("Well done, $name. Here is your reward.");
		quest::summonitem("27724"); #Denon's Horn of Disaster
		quest::exp(100000);
	}
	#Imp Statuette, Dull Stone, Amulet of Woven Hair
	elsif(($itemcount{20953} == 1) && ($itemcount{20826} == 1) && ($itemcount{20827} == 1)) {
		quest::summonitem("14565"); #Fae amulet
		quest::exp(100000);
		quest::say("Well done, $name. Here is your reward.");
	}
	#Efreeti War Spear, Manna Nectar, Nebulous Emerald, Nebulous Diamond
	elsif(($itemcount{20831} == 1) && ($itemcount{20968} == 1) && ($itemcount{20832} == 1) && ($itemcount{20833} == 1)) {
		quest::summonitem("10852"); #Harmonic Spear
		quest::exp(100000);
		quest::say("Well done, $name. Here is your reward.");
	} else {
		plugin::return_items(\%itemcount);
	}
}

sub EVENT_TIMER {
	quest::depop();
	quest::stoptimer("depop");
}
#END of FILE Zone:airplane  ID:71099 -- Will Treewalker