sub EVENT_SPAWN {
  my $x = $npc->GetX();
  my $y = $npc->GetY();
  my $z = $npc->GetZ();
  quest::set_proximity($x - 5000, $x + 5000, $y - 5000, $y + 50000, $z -5000, $z);
}

sub EVENT_ENTER {
    quest::movepc(9,-1258.95,-7387,27.51);
}

sub EVENT_EXIT {
  quest::clear_proximity();
  my $x = $npc->GetX();
  my $y = $npc->GetY();
  my $z = $npc->GetZ();

  quest::set_proximity($x - 5000, $x + 5000, $y - 5000, $y + 50000, $z -5000, $z);
}

