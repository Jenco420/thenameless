#Frederic Calemin for Magician tests of clarification, empowerment, shielding, gesticulation

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Great, let us waste no more time! I offer to you three challenges. [Clarification], [Empowerment], [Shielding], and [Gesticulation]. Please choose one of these.");
        }

#Test of Clarification
if ($text =~/clarification/i)
	{
        quest::say ("Clarification it is. Proceed upward through the sky and return to me a Crimson Tessera, an Ethereal Sapphire, and Feathered Cape. This will prove your abilities to me and I will reward you with the Bracelet of Clarification.");
        }

#Test of empowerment
elsif ($text =~/empowerment/i)
	{
        quest::say ("Empowerment it is. Proceed upward through the sky and return to me an Iron Disk, a Gem of Empowerment, and a Ceramic Mask. This will prove your abilities to me and I will reward you with the Mask of Empowerment.");
        }

#Test of shielding
elsif ($text =~/shielding/i)
	{
        quest::say ("Shielding it is. Proceed upward through the sky and return to me a Hyaline Globe, an Ivory Pendant, and a Gold Coffer. This will prove your abilities to me and I will reward you with an Gold White Pendant.");
        }

#Test of gesticulation
elsif ($text =~/gesticulation/i)
	{
        quest::say ("Gesticulation it is. Proceed upward through the sky and return to me an Efreeti Magi Staff, Sweet Nectar, a Sphinx Crown, and a Hazy Opal.  This will prove your abilities to me and I will reward you with the staff of the Magister");
        }
}

sub EVENT_ITEM
{
#Test of Clarification turn in
if(plugin::check_handin(\%itemcount, 20931 => 1, 20754 => 1, 20755 => 1)) #Crimson Tessera, Ethereal Sapphire, Feathered Cape
	{
	quest::summonitem("1274"); #Bracelet of Clarification
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of empowerment turn in
elsif(plugin::check_handin(\%itemcount, 20937 => 1, 20756 => 1, 20755 => 1)) #Iron Disc, Gem of empowerment, Ceramic Mask
	{
	quest::summonitem("2707"); #Mask of Empowerment
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of shielding turn in
elsif(plugin::check_handin(\%itemcount, 20944 => 1, 20758 => 1, 20759 => 1)) #Hyaline Globe, Ivory Pendant, Golden Coffer
	{
	quest::summonitem("14557"); #Gold White Pendant
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of gesticulation turn in
elsif(plugin::check_handin(\%itemcount, 20870 => 1, 20966 => 1, 20871 => 1, 20872 => 1)) #Efreeti Magi Staff, Sweet Nectar, Sphinx Crown, Hazy Opal
	{
	quest::summonitem("11650"); #Staff of the Magister
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71098 -- Frederic_Calemin