#Vanquisher #2 71127
sub EVENT_SPAWN
{
quest::signalwith("71116","99","1"); #signal to signal watcher 1 when killed
quest::signalwith("71011","99","1"); #signal to signal watcher 1 when killed
quest::signalwith("71010","99","1"); #signal to signal watcher 1 when killed
}

sub EVENT_DEATH
{
quest::signalwith("71116","5","1"); #signal to signal watcher 1 when killed
quest::signalwith("71011","1","1"); #signal to signal watcher 1 when killed
quest::signalwith("71010","1","1"); #signal to signal watcher 1 when killed
}