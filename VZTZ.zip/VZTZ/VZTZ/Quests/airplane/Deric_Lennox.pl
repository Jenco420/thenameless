#Deric Lennox Cleric test of Resolution, the weak, and theurgy

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Greetings there lad. Come seekin glory then have ya? Alrighty then, glorious ye shall be. Take me tests here, and I will show ya the light there. Take ye the [Test of Resolution], [Test of Theurgy], or [Test of the Weak]?");
        }

#Test of Resolution
elsif ($text =~/Resolution/i)
	{
        quest::say ("The test of resolution be an easy one. Trust me there! Just needin bring me a Spiroc Stattuete, a Spiroc Healing Totem, and a Silvered Spiroc Necklace. Ne'r liked those birdies anyway.");
        }

#Test of the Weak
elsif ($text =~/weak/i)
	{
        quest::say ("Aye, the weak. I laugh at em. Right after I put em in there places. Aye. Bring me there lad, a Efreeti Standard, a Manna Nectar, Mithril Bands, and a Shimmering Topaz. Yup, that'll do it.");
        }

#Test of theurgy
elsif ($text =~/Theurgy/i)
	{
        quest::say ("The test of Theurgy. Ne'r understood it meself. It calls fer you ta bring me an Efreeti Mace, a Saffron Spiroc Feather, a Glowing Sapphire, and a Djinni Aura.");
        }
}

sub EVENT_ITEM
{

#Cleric test of resolution turn in
if(plugin::check_handin(\%itemcount, 20813 => 1, 20812 => 1, 20954 => 1)) #Silvered Spiroc necklace, Spiroc healing totem, Spiroc Statuette
	{
	quest::summonitem("14562"); #Necklace of Resolution
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Cleric test of The weak turn in
elsif(plugin::check_handin(\%itemcount, 20817 => 1, 20968 => 1, 20819 => 1, 20818 => 1)) #Efreeti Standard, Manna Nectar, Mithril Bands, Shimmering Topaz
	{
	quest::summonitem("11691"); #Truwian Baton
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Cleric test of Theurgy turn in
elsif(plugin::check_handin(\%itemcount, 20816 => 1, 20961 => 1, 20814 => 1, 20815 => 1)) #Efreeti Mace, Saffron Spiroc Feather, Glowing Sapphire, Djinni Aura
	{
	quest::summonitem("27718"); #Theurgist's Star
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71108 -- Deric Lennox