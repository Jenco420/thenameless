sub EVENT_SIGNAL
{
if($signal eq 1){
quest::shout("Debug:: Island1 signal received.  Setting Timer::Island1 to 30 seconds.");
quest::settimer("Island1", 30);
}
if($signal eq 2){
quest::shout("Debug:: Island2 signal received.  Setting Timer::Island2 to 30 seconds.");
quest::settimer("Island2", 30);
}
if($signal eq 3){
quest::settimer("Island3", 5);

}


#quest::shout("Debug:: Signal Received from $npcid");
#quest::settimer("entcheck", 20);
#quest::stoptimer("spawnnpc");
}

sub EVENT_TIMER
{
	if($timer eq "Island1")
	{
		quest::spawn2(71032,0,0,493,1370,-646,24);
		quest::shout("Debug:: No signal received/Timer Expired.  Spawning 71032 (a Thunder Spirit Princess) at (x, y, z) 493, 1370, -646");
		quest::stoptimer("Island1");
		quest::shout("Debug:: Stopping Timer::Island1");
	}
	if($timer eq "Island2")
	{
		quest::spawn2(71059,0,0,-570,-140,-314,128);
		quest::shout("Debug:: No signal received/Timer Expired.  Spawning 71059 (Protector of Sky) at (x, y, z) -570, -140, -314");
		quest::stoptimer("Island2");
		quest::shout("Debug:: Stopping Timer::Island2");
	}
	if($timer eq "Island3")
	{
		quest::spawn2(71078,0,0,-1540.4,660.72,126.52,$h);
		quest::shout("Debug:: Spawning Keeper of Souls");
		quest::stoptimer("Island3");
	}

}


