sub EVENT_SPAWN
{
quest::signalwith("71012","99","0");
$spawnCheck = 0;
}

sub EVENT_DEATH
{
quest::signalwith("71012","1","0");
if ($spawnCheck == 0)
{
quest::spawn2(71013,0,0,769.31,-867.62,421,$h); #respawn Guardian
}
}

sub EVENT_SIGNAL
{
if($signal eq 1) 
	{
	$spawnCheck += 1;
	}

}