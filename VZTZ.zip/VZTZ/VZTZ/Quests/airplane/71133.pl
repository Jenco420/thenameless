sub EVENT_SPAWN {
  my $x = $npc->GetX();
  my $y = $npc->GetY();
  my $z = $npc->GetZ();
  quest::set_proximity($x, $x + 5000, $y, $y + 50000, $z, $z + 50);
}

sub EVENT_ENTER {
    quest::shout("Test")
    quest::safemove();
    #quest::movepc(9,-1258.95,-7387,27.51);
}

sub EVENT_EXIT {
  quest::clear_proximity();
  my $x = $npc->GetX();
  my $y = $npc->GetY();
  my $z = $npc->GetZ();

  quest::set_proximity($x, $x + 5000, $y, $y + 50000, $z, $z + 50);

}

