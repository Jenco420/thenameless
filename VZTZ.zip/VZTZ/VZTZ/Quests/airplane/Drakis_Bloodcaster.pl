#Drakis Bloodcaster for Necro tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Necromancer')){  quest::say ("Greetings, $name. Are you ready [to begin]?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Necromancer, begone!");
}
if ($text =~/begin/i && ($class eq 'Necromancer')){  quest::say ("Who would you like to be tested by? {Jzil GSix] or [Dugaas Helpyre]?");  }

	#summon Jzil GSix
	if(($text=~/Jzil/i) && ($class eq "Necromancer")) {quest::say("I shall summon them for you");
	quest::spawn2(71095,0,0,654.9,1305,-762.2,22);
	quest::depop();
	}

	#summon Dugaas Helpyre
	if(($text=~/Dugaas/i) && ($class eq "Necromancer")){quest::say("I shall summon them for you");
	quest::spawn2(71094,0,0,661.6,1302.8,-766.9,254.9);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71084 -- Drakis Bloodcaster