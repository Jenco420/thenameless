sub EVENT_SAY { 
	if($text=~/Hail/i){
		quest::say("Peace to you, $name.  I see that you have come far along the path of tranquility and enlightenment.  Do you wish to test yourself further, and perhaps complete the path you started on so long ago?"); 
	}
}
#END of FILE Zone:airplane  ID:2582 -- Holwin 