#Torgon_Blademaster for Warrior tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Warrior')){  quest::say ("Greetings, $name. Are you a [true warrior?]");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Warrior, begone!");
}
if ($text =~/warrior/i && ($class eq 'Warrior')){  quest::say ("Then you shall be tested as one.  Choose.  Do you wish to be tested by [Farlorn] or [Ogog]?");  }

	#summon Farlorn
	if(($text=~/Farlorn/i) && ($class eq "Warrior")){quest::say("I shall summon them for you");
	quest::spawn2(71104,0,0,563.3,1392.4,-766.9,63.4);
	quest::depop();
	}

	#summon Ogog
	if(($text=~/Ogog/i) && ($class eq "Warrior")){quest::say("I shall summon them for you");
	quest::spawn2(71064,0,0,563.3,1392.4,-766.9,63.4);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71045 -- Torgon Blademaster