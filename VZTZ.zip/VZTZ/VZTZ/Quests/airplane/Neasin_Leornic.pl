#Neasin Leornic for Wizard tests of concentration, Focus, Meditation

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Great, let us waste no more time! Do you wish to begin your test of [concentration], [focus], or [meditation?]");
        }

#Test of Concentration
elsif ($text =~/concentration/i)
	{
        quest::say ("Concentration it is. Proceed upward through the sky and return to me an Azure Tessera, an Augmentor&rsquos Gem, and a Grey Damask Cloak. This will prove your ability to concentrate and I will reward you with an Augmentors Cloak.");
        }

#Test of focus
elsif ($text =~/focus/i)
	{
        quest::say ("Focus is a must. Travel among the residents of the sky and bring to me an Iron Disk, an Ethereal Opal, and a Woven Skull Cap. This will prove your ability to focus and I will reward you with Al`Kabors Cap.");
        }

#Test of meditation
elsif ($text =~/meditation/i)
	{
        quest::say ("Meditation, the fix for all. Fly to those above and return to me a Hyaline Globe, a Sky Topaz, and a High Quality Raiment. If you are successful, I will reward you with the Raiment of Thunder.");
        }
}

sub EVENT_ITEM {

#Test of Concentration turn in
if (plugin::check_handin(\%itemcount, 20930 => 1, 20741 => 1, 20742 => 1)) #Azure Tessera, Augmentor's Gem, Grey Damask Cloak
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("1272"); #Augmentor's Mask
	quest::exp(100000);
	}

#Test of focus turn in
elsif(plugin::check_handin(\%itemcount, 20937 => 1, 20743 => 1, 20744 => 1)) #Iron Disc, Ethereal Opal, Woven Skull Cap
	{
	quest::summonitem("1271"); #Al'Kabor's Cap of Binding
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of meditation turn in
elsif(plugin::check_handin(\%itemcount, 20944 => 1, 20745 => 1, 20746 => 1)) #Hyaline Globe, Sky Topaz, High Quality Raiment
	{
	quest::summonitem("1273"); #Raiment of Thunder
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}


#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71088 -- Neasin Leornic