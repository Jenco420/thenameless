#Spiroc Arbiter
sub EVENT_SPAWN
{
$Arbiter = 1;
}

sub EVENT_SIGNAL {

if($signal eq 1) 
	{
	$Arbiter -= 1;
	}
	
if($signal eq 99) 
		{
	if ($Arbiter < 1) {
		$Arbiter += 1;
		}
	}
	
}

sub EVENT_DEATH
{
if ($Arbiter == 1)
	{
        quest::spawn2(71008,22,0,1119.04,-776.41,444.72,$h); #spawn arbiter again if vanquisher is not dead
        }
}

