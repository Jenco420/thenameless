#Spawn 71082 - Bizazzt   after killing 71111

sub EVENT_SPAWN {
	quest::settimer("depop",4800);
}





sub EVENT_DEATH {
	quest::spawn2(71082,0,0,$x,$y,$z,$h);
}