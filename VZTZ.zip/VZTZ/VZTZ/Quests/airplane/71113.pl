#Spawn 3 71081 - Bazzzazzt  after killing 71113

sub EVENT_SPAWN {
	quest::settimer("depop",4800);
}


sub EVENT_DEATH {
	quest::spawn2(71081,0,0,$x,$y,$z,$h);
        quest::spawn2(71081,0,0,$x,$y,$z,$h);
        quest::spawn2(71081,0,0,$x,$y,$z,$h);
}