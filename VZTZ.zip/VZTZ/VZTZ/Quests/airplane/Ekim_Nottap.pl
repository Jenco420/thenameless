#Spawn Soul Carrier x2 after killing Soul harvester

#sub EVENT_SPAWN {
#quest::setglobal("Ekim","1","0","F");
#}

#sub EVENT_TIMER {
#quest::settimer(timerID,seconds)
#}

sub EVENT_DEATH {
  quest::spawn2(71078,0,0,$x,$y,$z,$h);
}