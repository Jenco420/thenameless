sub EVENT_SPAWN {
quest::settimer("depop2",4800);
}

sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop2");
        }


sub EVENT_DEATH
{
quest::spawn2(71074,0,0,$x,$y,$z,$h)#spawn Sirran the Lunatic (Island #4 version)
}

