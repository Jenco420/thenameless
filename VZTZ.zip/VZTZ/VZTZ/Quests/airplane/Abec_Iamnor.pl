#Ogog for warrior test of Think, Bash, Smash

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Ogog not smart, but Ogog smarter than you.  [You ready] for Ogog or no?");
        }

#Tests start
elsif ($text =~/ready/i)
	{
        quest::say ("Ok, $name.  Ogog got some hard things for you.  You do [bash], [smash], or [think] test?");
        }

#Test of think
elsif ($text =~/think/i)
	{
        quest::say ("Ogog think that you do this one maybe. Ogog no know though. You bring Ogog efreeti belt, pegasus statue, a spiroc wind totem and tablet. Ogog say good luck!");
        }

#Test of bash
elsif ($text =~/bash/i)
	{
        quest::say ("This one hard. Ogog like it. Ogog need Efreeti battle axe, some honey nectar, bottled djinni, and ethereal emerald. Then Ogog make you best basher.");
        }

#Test of smash
elsif ($text =~/smash/i)
	{
        quest::say ("Ogog smash good. . . Ogog no think you can smash good. But Ogog let you try. You get Ogog Djinni War Blade, some veerulent wasp poison and a mottled spiroc feather. Ogog say you good warrior if you do this!");
        }
}

sub EVENT_ITEM {

#Test of think turn in
if (plugin::check_handin(\%itemcount, 20976 => 1, 20949 => 1, 20977 => 1, 20978 => 1)) #Efreeti Belt, Pegasus Statuette, Spiroc Wind Totem, Wind Tablet
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("11673"); #Belt of the Four Winds
	quest::exp(100000);
	}

#Test of bash turn in
elsif(plugin::check_handin(\%itemcount, 20983 => 1, 20829 => 1, 20981 => 1, 20982 => 1)) #Efreeti Battle Axe, Honey Nectar (Needs to be added to the database) bottled djinni, ethereal emerald
	{
	quest::summonitem("11675"); #Fangol
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Smash turn in
elsif(plugin::check_handin(\%itemcount, 20980 => 1, 20979 => 1, 20956 => 1)) #Djinni War Blade Virulent wasp poison (this item needs to be added to the database), mottled spiroc feather
	{
	quest::summonitem("11674"); #Dagas
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}


#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71064 -- Ogog