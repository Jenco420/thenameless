#Aarkis Ebonblade for Shadowknight tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Shadowknight')){  quest::say ("Greetings. $name.  Have you come here to [test your dark powers] of skill and spell casting?");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Shadowknight, begone!");
}
if ($text =~/test/i && ($class eq 'Shadowknight')){  quest::say ("You will be tested by either [Gragrot] or Tynicon D'Lin.  Choose one!");  }

	#summon Gragrot
	if(($text=~/gragrot/i) && ($class eq "Shadowknight")) {quest::say("I shall summon them for you");
	quest::spawn2(71063,0,0,563.3,1351.9,-766.9,63.4);
	quest::depop();
	}

	#summon Tynicon D'Lin
	if(($text=~/tynicon/i) && ($class eq "Shadowknight")){quest::say("I shall summon them for you");
	quest::spawn2(71105,0,0,563.3,1351.9,-766.9,63.4);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71048 -- Sarkis Ebonblade