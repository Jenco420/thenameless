#Magus Frinon For Magician Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Magician')){  quest::say ("Greetings, $name.  Have you come here [to be tested]??");  }
elsif($text=~/Hail/i){  quest::say ("You are not a Magician, begone!");
}
if ($text =~/to be tested/i && ($class eq 'Magician')){  quest::say ("Choose who you wish to be tested by, [Frederic Calemin] or [Roanis Elindar]");  }

	#summon Frederic Calemin
	if(($text=~/Frederic/i) && ($class eq "Magician")) {quest::say("I shall summon them for you");
	quest::spawn2(71090,0,0,614.5,1304.1,-766.9,255);
	quest::depop();
	}

	#summon Roanis Elindar
	if(($text=~/Roanis/i) && ($class eq "Magician")){quest::say("I shall summon them for you");
	quest::spawn2(71091,0,0,614.5,1304.1,-766.9,255);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71050 -- Magus Frinon