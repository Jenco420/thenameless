sub EVENT_SPAWN
{
quest::signalwith("71013","99","1");
#quest::setglobal("Vanquisher","0","0","F");
}

sub EVENT_DEATH
{
quest::signalwith("71013,"1","1");
#quest::targlobal("Guardian","1","F",71012,$user,$zoneid);
}
