#spiroc  revolter
sub EVENT_SPAWN
{
$Revolter = 1;
}

sub EVENT_SIGNAL {

if($signal eq 1) 
	{
	$Revolter -= 1;
	}
	
if($signal eq 99) 
		{
	if ($Revolter < 1) {
		$Revolter += 1;
		}
	}
	
}

sub EVENT_DEATH
{
if ($Revolter == 1)
	{
        quest::spawn2(71010,19,0,703.42,-514.32,446.27,$h); #spawn Revolter again if vanquisher is not dead
        }
}

