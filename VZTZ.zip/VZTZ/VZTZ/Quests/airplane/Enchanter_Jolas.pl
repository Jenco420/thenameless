#Enchanter Jolas For Enchanter Tests

sub EVENT_SAY {
if (($text =~/Hail/i)&&($class eq 'Enchanter')){  quest::say ("Greetings, $name.  Have you come here to [test your powers of enchantment]?");  }
elsif($text=~/Hail/i){  quest::say ("You are not an Enchanter, begone!");
}
if ($text =~/to be tested/i && ($class eq 'Enchanter')){  quest::say ("I am most honored to be able to help you. Please choose from one of my instructors. [Lelulean] or [Enderbite].");  }

	#summon Lelulean
	if(($text=~/lelulean/i) && ($class eq "Enchanter")) {quest::say("I shall summon them for you");
	quest::spawn2(71092,0,0,660.7,1368.4,-766.9,192.6);
	quest::depop();
	}

	#summon Enderbite
	if(($text=~/enderbite/i) && ($class eq "Enchanter")){quest::say("I shall summon them for you");
	quest::spawn2(71093,0,0,660.7,1388.9,-766.9,192.6);
	quest::depop();
	}
}

#END of FILE Zone:airplane  ID:71042 -- Enchanter Jolas



