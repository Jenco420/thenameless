#spawn watcher1
sub EVENT_SPAWN
{
$Azarack = 0;
$Vanquishers = 0;
$HarvesterCheck = 0;

}



sub EVENT_SIGNAL
{
if($signal eq 1)
	{
	quest::shout("Debug:: Island1 signal received.  Setting Timer::Island1 to 30 seconds.");
	quest::settimer("Island1", 30);
	}
if($signal eq 2)
	{
	quest::shout("Debug:: Island2 signal received.  Setting Timer::Island2 to 30 seconds.");
	quest::settimer("Island2", 30);
	}
if($signal eq 3)
	{
	if ($HarvesterCheck == 0) {
	$HarvesterCheck = 1;
	quest::settimer("Island4", 4800);
	}
	}
if($signal eq 4)
	{
	$Azarack += 1;
	if ($Azarack == 9)
		{
		quest::spawn2(71059,0,0,-674.26,-334.68,-328.23,$h); #spawn protector of sky
		$Azarack = 0;
		}
	}
if ($signal eq 5) #called whenever a vanquisher dies
	{
	$Vanquishers += 1;
	if ($Vanquishers > 2) {
		quest::signalwith("71013","1","1");
	}
	quest::shout($Vanquishers);
	}



if($signal eq 98) 
	{
	if ($Vanquishers > 0) {
		$Vanquishers -= 1;
	}
	}
	

if($signal eq 99) 
	{
	if ($Azarack > 0) {
		$Azarack -= 1;
		}
	}
	


#quest::shout("Debug:: Signal Received from $npcid");
#quest::settimer("entcheck", 20);
#quest::stoptimer("spawnnpc");
}

sub EVENT_TIMER
{
	if($timer eq "Island1")
	{
		quest::spawn2(71032,0,0,493,1370,-646,24);
		quest::shout("Debug:: No signal received/Timer Expired.  Spawning 71032 (a Thunder Spirit Princess) at (x, y, z) 493, 1370, -646");
		quest::stoptimer("Island1");
		quest::shout("Debug:: Stopping Timer::Island1");
	}
	if($timer eq "Island2")
	{
		quest::spawn2(71059,0,0,-570,-140,-314,128);
		quest::shout("Debug:: No signal received/Timer Expired.  Spawning 71059 (Protector of Sky) at (x, y, z) -570, -140, -314");
		quest::stoptimer("Island2");
		quest::shout("Debug:: Stopping Timer::Island2");
	}
	if($timer eq "Island4")
	{
		$HarvesterCheck = 0;
		quest::spawn2(71078,0,0,-1540.4,660.72,126.52,$h);
		quest::stoptimer("Island4");
	}

}


