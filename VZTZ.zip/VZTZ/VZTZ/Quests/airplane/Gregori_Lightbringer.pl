#Gregori Lightbring for Paladin test of compassion, Love, Sacrifice

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("The test of the heart is in three parts.  [Compassion], [Sacrifice] and [Love]. Choose one and we will begin.");
        }

#Test of Compassion
if ($text =~/compassion/i)
	{
        quest::say ("Compassion is of great importance to us. Without it, we do not feel empathy, and cannot truly follow the path we claim to travel. Return to me an Efreeti two handed sword, dulcet nectar, a golden hilt, and a large sky diamond. If you present these to me, I will award you Truvinan, the divine wind.");
        }

#Test of love
elsif ($text =~/love/i)
	{
        quest::say ("Love is what makes us close to the gods we follow. Without it, we could not truly worship them, and would be lost. Prove yourself to me and return with a dark spiroc feather, ethereal topaz, and a sphinxian claw. In return I will give you Zephywind.");
        }

#Test of Sacrifice
elsif ($text =~/sacrifice/i)
	{
        quest::say ("You have sacrificed much to come so far. Sacrifice this one last time and the sword of ocean breeze shall be yours. Retrieve a griffon statuette, a spiroc peace totem, and a bixie sword blade.");
        }
}

sub EVENT_ITEM
{
#Test of Compassion Turn in
if(plugin::check_handin(\%itemcount, 20725 => 1, 20964 => 1, 20726 => 1, 20727 =>1)) #Efreeti Zweihander, Dulcet Nectar, Golden Hilt, Large Sky Diamond
	{
	quest::summonitem("11682"); #Truvinan
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#Test of Love Turn in
elsif(plugin::check_handin(\%itemcount, 20957 => 1, 20723 => 1, 20724 => 1)) #Dark Spiroc Feather, Ethereal Topaz, Sphinx claw
	{
	quest::summonitem("207709"); #Thelovorn, Blade of Light
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Sacrifice Turn in
elsif(plugin::check_handin(\%itemcount, 20950 => 1, 20721 => 1, 20722 => 1)) #Friffon Statuette, Spiroc Peace Totem, Bixie Sword Blade
	{
	quest::summonitem("27708"); #Aldryn, Blade of the Ocean
	quest::exp(100000);
	quest::say("Excellent! Take this as your reward.");
	}

#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71106 -- Gregori Lightbringer