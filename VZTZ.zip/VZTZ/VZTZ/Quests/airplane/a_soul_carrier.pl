#Spawn Essence Tamer after killing essence carrier
my $mob1;
my $mob2;
my $mobnpc1;
my $mobnpc2;
my $entid1;

sub EVENT_SPAWN {
quest::settimer("depop",4800);
}


sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
        
sub EVENT_DEATH
{
$entid1 = quest::spawn2 (71123,0,0,$x,$y,$z,$h);
$mob1 = $entity_list->GetMobID($entid1);
$mobnpc1 = $mob1->CastToNPC();
$mobnpc1->AddToHateList($npc->GetHateTop());
}

