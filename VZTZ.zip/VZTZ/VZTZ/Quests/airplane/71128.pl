#Vanquisher #3 71128

sub EVENT_SPAWN
{
quest::signalwith("71116","99","1"); #signal to signal watcher 1 when killed
quest::signalwith("71014","99","1"); #signal to signal watcher 1 when killed
quest::signalwith("71015","99","1"); #signal to signal watcher 1 when killed
}
sub EVENT_DEATH
{
quest::signalwith("71116","5","1"); #signal to signal watcher 1 when killed
quest::signalwith("71014","1","1"); #signal to signal watcher 1 when killed
quest::signalwith("71015","1","1"); #signal to signal watcher 1 when killed
}