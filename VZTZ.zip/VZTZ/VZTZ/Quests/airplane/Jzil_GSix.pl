#Jzil GSix for Necromancer tests of Flight, Power, Mind

sub EVENT_SPAWN {
quest::settimer("depop",300);
}

sub EVENT_SAY {
if (($text =~/Hail/i))
	{
        quest::say ("Ah, so you have come to be tested. Many fine things can be your reward. There are three tests which I can administer. Shall you take the test of [flight], [power], or [mind]?");
        }

#Test of Flight
elsif ($text =~/Flight/i)
	{
        quest::say ("So, you wish the test of flight? So be it. You must return to me a Verdant Tessera, and Ebon Shard, and a Griffons Beak to reap your rewards. May the darkness guide your steps.");
        }

#Test of Power
elsif ($text =~/power/i)
	{
        quest::say ("So, the test of power it be. Prove yourself worthy of power and brng me a Silver Disk, a Spirok Feather, and a Black Silk Cape. Only then, will you know true power");
        }

#Test of Mind
elsif ($text =~/Mind/i)
	{
        quest::say ("So, the test of mind it shall be. You must return to me, from this place of air and mist, a Rogous Globe, some Djinni Blood, and some Fine Cloth Raiments. Then, and only then, you shall have the reward that you deserve!");
        }
}

sub EVENT_ITEM {

#Test of Flight turn in
if (plugin::check_handin(\%itemcount, 20932 => 1, 20780 => 1, 20781 => 1)) #Verdant Tessera, Ebon Shard, Griffons Beak
	{
	quest::say("Well done, $name. Here is your reward.");
	quest::summonitem("27712"); #Bloody Griffon-Hide Wrist Guard
	quest::exp(100000);
	}

#Test of Power turn in
elsif(plugin::check_handin(\%itemcount, 20838 => 1, 20782 => 1, 20783 => 1)) #Silver Disc, Spiroc Featers, Black Silk Cape
	{
	quest::summonitem("1278"); #Cloak of Spiroc Feathers
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}

#Test of Mind turn in
elsif(plugin::check_handin(\%itemcount, 20945 => 1, 20784 => 1, 20785 => 1)) #Rugous Globe, Djinni Blood, Fine Cloth Raiments
	{
	quest::summonitem("1279"); #Blood Soaked Raiment
	quest::exp(100000);
	quest::say("Well done, $name. Here is your reward.");
	}


#return items if they do not match
else
	{
        quest::say("What am I supposed to do with these?");
        plugin::return_items(\%itemcount);
        }
}

#despawn mob after timer is up
sub EVENT_TIMER
	{
        quest::depop();
        quest::stoptimer("depop");
        }
#END of FILE Zone:airplane  ID:71095 -- Jzil GSix