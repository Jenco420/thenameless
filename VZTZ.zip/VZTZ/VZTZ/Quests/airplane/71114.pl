#Spawn 71110 - Bazzzazzt after killing 71114

sub EVENT_SPAWN {
	quest::settimer("depop",4800);
}




sub EVENT_DEATH {
	quest::spawn2(71110,0,0,$x,$y,$z,$h);
}