sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail! I'd love to stop and chat with ya but I'm running late to an appointment in Freeport with a fletcher interested in my superior wooden shafts."); }
}
#END of FILE Zone:ecommons  ID:22025 -- Jimble_Woodentoe 

