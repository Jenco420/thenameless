
sub EVENT_ATTACK {
	quest::say("Death to all who oppose Innoruuk's will!!");
}

sub EVENT_DEATH {
	quest::say("Innoruuk has seen what you have done. His hate, along with the Dismal Rage, will find you.");
}


sub EVENT_SPAWN {
	quest::settimer(1,2160);
}

sub EVENT_TIMER {
	if($timer == 1){
		quest::depop;
	}
}