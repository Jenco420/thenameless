sub EVENT_SAY {
	if($text=~/hail/i){
		quest::say("Greetings, traveler! Have you need of provisions or perhaps other wares? I sell what I find upon the battlegrounds of the Commonlands.");
		quest::pause(10);
	}
	if($text=~/house/i){
		quest::say("My house is along the road that leads to the west.  Hurry now!");
		quest::pause(5);
	}
}


sub EVENT_ITEM {
	if($itemcount{18896} == 1){
		quest::say("You are the one they have sent? A squire?!! I hope you can help me. I gather items strewn upon the grounds of the Commonlands. I sell them at good prices. Lately, I have been terrorized by a human rogue named Narl. He will no doubt appear at my [house] soon. Bring his head to me.");
		quest::settimer(1,45);
		quest::pause(30);
	}
	elsif($itemcount{13867} == 1){
		quest::say("You have performed a great service to me, but I fear others will attack me while I stroll the countryside. It would be very noble of you to fetch me a cloth shirt for protection from wicked creatures. It is not much, but it will help.");
		quest::givecash("7","0","0","0");
		quest::faction("184","10");
		quest::faction("86","-50");
		quest::faction("258","10");
		quest::pause(30);
	}
	elsif($itemcount{1004} == 1){
		quest::say("Thank you. You are very noble for a squire. I can see you becoming a very valuable asset to the Hall of Truth. Take this token. Tell Merko that you have [earned the Token of Generosity].");
		quest::summonitem("13865");
		quest::faction("184","1");
		quest::faction("258","1");
		quest::faction("86","-5"); 
	} else {
		quest::say("I need at least two of the case keys and the gem case.");
		plugin::return_items(\%itemcount);
	}
}

sub EVENT_TIMER {
	if($timer == 1){
		quest::unique_spawn(22196,0,0,1646.23,-82.63,-53);
		quest::stoptimer(1);  
	}
}