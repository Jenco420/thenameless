
my $pickTarget;
my $hateRand;
my $hateTop;
my $hateName;
my $hateID;
my $x;
my $y;
my $z;
my $h;

sub EVENT_AGGRO
{
quest::shout("You will not have me Tunare!");
}

sub EVENT_COMBAT
{
    #1 - enter combat, 0 - leave combat
    if($combat_state == 1)
    {
	$hateRand = $npc->GetHateRandom();
        $hateID = $hateRand->GetID(); 
        $npc->CastSpell(7111, $hateID);
        $npc->CastSpell(8449, '58060');
        quest::settimer("buff", 40);
        quest::settimer("barrier", 10);
        quest::settimer("detonate", 20);
    }
    elsif($combat_state == 0)
    {
        $npc->CastSpell(8449, '58060');
        quest::stoptimer("buff");
        quest::stoptimer("barrier");
        quest::stoptimer("detonate");
        #heals mob to full - make # equal to total health of NPC
        $npc->SetHP(64000);
    }
}


sub EVENT_TIMER
{
    
    if ($timer eq "buff")
    {
        $npc->CastSpell(8450, '58060');
    }
    if ($timer eq "barrier")
    {
	$hateRand = $npc->GetHateRandom();
        $hateID = $hateRand->GetID();
        $npc->CastSpell(7111, $hateID);
    }
    
    if ($timer eq "detonate")
    {
	$hateRand = $npc->GetHateRandom();
        $hateID = $hateRand->GetID();
        $npc->CastSpell(8471, $hateID);
    }
    
}

sub EVENT_SLAY
{
    $npc->CastSpell(8450, '58060');
}


sub EVENT_DEATH
{
  	quest::shout("Noooo!");  
}
 