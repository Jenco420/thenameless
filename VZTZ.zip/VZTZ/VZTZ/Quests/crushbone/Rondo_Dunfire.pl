#Rondo_Dunfire, Crushbone
#Status: COMPLETE

sub EVENT_ATTACK
{
  quest::say("Pardon me.  Is that my dagger in your back!!");
}

sub EVENT_DEATH
{
  quest::say("You shall soon feel the daggers of the Butcherblock Bandits upon your back!!");
}
