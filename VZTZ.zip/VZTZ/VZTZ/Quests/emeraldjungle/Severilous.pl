sub EVENT_DEATH {
	# Write Log File
	quest::write("Severilous.txt", "Time: $zonetime || Guild ID: $uguildid || Location: $x, $y, $z, $h");
}