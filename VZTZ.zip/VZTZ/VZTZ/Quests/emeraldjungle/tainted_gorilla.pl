my $x;
my $y;
my $z;
my $h;
my $entid1;
my $mob1;
my $mob1attack;

sub EVENT_DEATH{
	$x = $npc->GetX();
	$y = $npc->GetY();
	$z = $npc->GetZ();
	$h = $npc->GetHeading();
	$entid1 = quest::spawn2(94140,0,0,$x,$y,$z,$h);
	$mob1 = $entity_list->GetMobID($entid1);
	$mob1attack = $mob1->CastToNPC();
	$mob1attack->AddToHateList($client, 1);
}