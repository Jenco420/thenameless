sub EVENT_SAY {
	if ($text=~/hail/i) {
		quest::say("Didn't think I was gone for good, did you? We're that much closer to finishing this trial of our strength, thanks to you.");
	}
}

sub EVENT_ITEM {
	if ($itemcount{20481} == 1) {
		quest::emote("smiles at you, then closes her eyes as she sets the gem 'Nature's Balance' into the crossguard and begins to channel her spirit into the sword. The ground rumbles loudly as she casts. She collapses in exhaustion after a short time. 'Take the blade, and perhaps you can finish this.");
		quest::say("You must strike at the heart of Innoruuk's lair. Bring a shattered gem and the mithril blade to Xanuusus. Only by weakening Innoruuk's grip over his realm can the balance of the land once again be restored. If we do not meet again, $name, remember you always have my eternal thanks.");
		quest::summonitem(20487);
		quest::exp(1000000);
		quest::depop();
	} else {
		plugin::return_items(\%itemcount);
		return;
	}
}