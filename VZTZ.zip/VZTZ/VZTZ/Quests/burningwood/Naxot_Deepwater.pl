sub EVENT_SAY {
	if($text=~/hail/i){
		quest::say("Beware these woods! The sarnak claim this land as their own and wicked creatures walk beneath the burning foliage.");
		quest::say("Praise the Triumvirate! Natasha sent you just in time! Those twisted sarnak summoners are summoning Ixiblat Fer as we speak! We must stop Ixiblat Fer while he is still weak or all of Norrath may be set aflame! Please do me one more favor, should I perish to this beast of fire. Give this note to Natasha when you next see her, and if you should perish and I survive, I will make sure the waters never forget your reflections of your deeds this day.");
	}
}  

sub EVENT_ITEM{
	if ($itemcount{28056} == 1){
		quest::summonitem(28052);
		quest::spawn2(87151,0,0,1500.0,-2000.3,-379.3,0.0);
	} else {
		quest::emote("will not take this item.");
		plugin::return_items(\%itemcount);
		return;
	}
}