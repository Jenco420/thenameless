# #translocator Jempar
# Erud's Crossing (erudsxing)
# Aramid September 2006
#

sub EVENT_SAY {
if($text=~/Hail/i){
quest::say("Hello there. There seem to be some strange problems with the boats in this area. The Academy of Arcane Sciences has sent a small team of us to investigate them. If you need to [travel to Erudin] or [travel to Qeynos] in the meantime, I can transport you to my companion there."); 
}
if($text=~/travel to erudin/i){
quest::selfcast("2290"); }

if($text=~/travel to qeynos/i){
quest::selfcast("2288"); }
}
  
  
sub EVENT_SIGNAL {
  if($signal == 199) {
    quest::spawn2(98046,0,0,4210.0,-1610.0,-287.3,0.0);
    quest::signalwith(98009,99,10000);
  }
}

#End of File - NPCID 98045 - #Translocator_Jempar
