sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Greetings!  You seek knowledge of our ways.  You shall find knowledge and you shall offer knowledge you have been taught.  What is the power of the Gatecallers?"); }
}
#END of FILE Zone:erudnint  ID:24073 -- Vasile_Jahnir 

