sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("Hail. citizen!! Have you business with me? If so. please speak quickly and be on your way."); }
}
#END of FILE Zone:erudnint  ID:24051 -- Chief_Adair 

