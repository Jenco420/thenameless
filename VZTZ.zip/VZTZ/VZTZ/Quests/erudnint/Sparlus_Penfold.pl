sub EVENT_SAY { 
if($text=~/Hail/i){
quest::say("You look like someone that has a nose for knowledge. You ought to buy a copy of the Odus Chronicle today and further your knowledge about current events."); }
}
#END of FILE Zone:erudnint  ID:24015 -- Sparlus_Penfold 

