##Richardo: http://everquest.allakhazam.com/db/quest.html?quest=276
##Zone: Erudin Palace
##NPC: Trilani_Parlone

sub EVENT_SAY{
if($text=~/hail/i)
{
quest::say("I am busy!");
}
}

sub EVENT_ITEM{
if($itemcount{1056})
{
quest::say("Ahh the family cloak, I remember this in our chest. I will focus my mind into the center soul that lyes dormant within this cloak and reactivate its true power!");
quest::doanim(43);
quest::summonitem(1057);
quest::say("Please care for this cloak, $name!");
}
else
{
quest::say("I am not a trash can, $name. Please take your junk back");
plugin::return_items(\%itemcount);
}
} 

